import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {API_URL} from '../config';

function fetchShop(vendorId) {
  return new Promise(async (resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
      .post(
        API_URL + 'api/getMyShop',
        {
          vendorId,
        },
        {
          headers: {
            Authorization: `bearer ${token}`,
          },
        },
      )
      .then(async (response) => {
        if (response.data.status === 200) resolve(response.data.data);
        else resolve([]);
      })
      .catch((err) => {
        reject(err);
      });
  });
}
function fetchShopDetails(id) {
  return new Promise(async (resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
      .get(`${API_URL}api/getOrder/${id}`, {
        headers: {
          Authorization: `bearer ${token}`,
        },
      })
      .then(async (response) => {
        if (response.data.status === 200) resolve(response.data.data);
        else resolve([]);
      })
      .catch((err) => {
        console.log(err);
        reject(err);
      });
  });
}
function fetchVendors() {
  return new Promise(async (resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
    .get(API_URL + 'api/getMyVendors', {
      headers: {
        Authorization: `bearer ${token}`,
      },
    })
    .then(async (response) => {
      if (response.data.status === 200) resolve(response.data.data);
      else resolve([]);
    })
    .catch((err) => {
      reject(err);
    });
  });
}
export const shopService = {
  fetchShop,
  fetchShopDetails,
  fetchVendors,
};
