'use strict';
import Home from './home/Home';
import Login from './login/login';
import Orders from './order/Orders';
import Singup from './signup/Singup';
import ProductDetail from './productDetail/ProductDetail';
import Checkout from './checkout/Checkout';
import OrderDetail from './orderDetail/OrderDetail';
import Cart from './cart/Cart';

export {Home, Login, Orders, Singup, ProductDetail, Checkout, OrderDetail, Cart};
