import React, {useEffect, useCallback} from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image,
  Dimensions,
  TouchableOpacity,
  ScrollView,
  TextInput,
} from 'react-native';

import {connect} from 'react-redux';
import {deleteProductFromCart, updateCartAmount} from '../../actions/cart';
import Icon from 'react-native-vector-icons/Feather';
import {useTranslation} from 'react-i18next';

const Window = Dimensions.get('window');

// components
import Body from '../../components/template/body/Body';
import Header from '../../components/template/header/Header';
import CartItem from './components/CartItem';

import {debounce} from 'lodash';

const Cart = (props) => {
  const {t} = useTranslation();
  const rtl = props.rtlCustomer;

  const [cartAmount, setCartAmount] = React.useState(0);
  const [totalCost, setTotalCost] = React.useState(0);
  const [discount, setDiscount] = React.useState(0);

  const handleProductAmountChange = (action, item) => {
    if (action === 'add')
      props.updateCartAmount({...item, amount: item.amount + 1});
    else props.updateCartAmount({...item, amount: item.amount - 1});
  };
  useEffect(() => {
    let total = 0;
    props.cartList.forEach((product) => {
      if (product.specialPrice > 0 && product.isSpecial) {
        total += product.amount * product.specialPrice;
      } else {
        // total += product.amount * product.price -
        // (product.price * discount) / 100;
        total +=
          (product.price - (product.price * discount) / 100).toFixed(2) *
          product.amount;
      }
    });
    setTotalCost(total);
  }, [props.cartList]);

  const search = useCallback(
    debounce(() => {
      console.log('Hello');
    }, 1000),
  );
  useEffect(() => {
    if (props.userDetails.percentDiscount)
      setDiscount(props.userDetails.percentDiscount);
  }, [props.userDetails]);

  return (
    <View style={{flex:1, backgroundColor:"#E5E5E5"}} >
      <ScrollView stickyHeaderIndices={[0]} style={styles.body}>
      <Header
            title="Cart"
            lang={false}
            right={true}
            cart={false}
            height={45}
            onSearchChange={(value) => props.searchOrders(value)}
          />  
        <View style={styles.detail}>
          {props.cartList.map((item, i) => (
            <CartItem item={item} key={i} />
          ))}
         
        </View>
        <View style={styles.viewbtnarea}>
          {!props.cartList.length && (
            <Text style={{marginBottom: 20, fontSize: 18}}>
              {t('No items in cart!')}
            </Text>
          )}
         
        </View>
        {/* <View style={styles.viewbtnarea}>
          <TouchableOpacity
            style={styles.viewbtn}
            onPress={() => {
              props.navigation.navigate('Home');
            }}>
            <Text style={{fontSize: 16, color: '#fff'}}>
              {t('go to store')}
            </Text>
          </TouchableOpacity>
        </View> */}
      </ScrollView>
      <View style={{ flexDirection:"column",bottom:20, backgroundColor: '#E5E5E5', justifyContent:"center", alignItems:"center"}}>
      <View style={{flexDirection: 'row', marginBottom:10}}>
            <Text style={{ fontSize: 18}}>
              Total Amount
            </Text>
            <Text
              style={{
                marginLeft: 130,
                // marginTop: 18,
                fontSize: 18,
                fontWeight: 'bold',
                color: '#ECA140',
              }}>
              $1500
            </Text>
          </View>
      <TouchableOpacity
            style={[
              styles.viewbtn,
              !props.cartList.length ? {backgroundColor: '#ECA140'} : {},
            ]}
            onPress={() => {
              props.navigation.navigate('Checkout');
            }}
            disabled={!props.cartList.length}>
            <Text
              style={{
                fontSize: 16,
                color: '#fff',
                width: 250,
                textAlign: 'center',
              }}>
              {t('Go to Checkout')}
            </Text>
          </TouchableOpacity>
          </View>
    </View>
  );
};

const styles = StyleSheet.create({
  body: {
    backgroundColor: '#E5E5E5',
    // height:"90%"
    flex:1
  },
  flexRow: {
    display: 'flex',
    flexDirection: 'row',
    width: Window.width < 370 ? '97%' : '97%',
  },
  flexRowRTL: {
    display: 'flex',
    flexDirection: 'row-reverse',
    width: Window.width < 370 ? '95%' : '96%',
    // backgroundColor: '#0f0'
  },
  cartpage: {
    width: Window.width,
    height: Window.height,
  },
  detail: {
    margin: 15,
    paddingHorizontal: 15,
    backgroundColor: '#E5E5E5',
    borderRadius: 3,
  },
  cartcard: {
    // paddingHorizontal: 30,
    paddingVertical: 20,
    justifyContent: 'space-between',
    borderBottomColor: '#eee',
    borderBottomWidth: 1,
    // position: 'relative',
  },
  viewbtnarea: {
    display: 'flex',
    marginTop: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  viewbtn: {
    backgroundColor: '#ECA140',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 5,
    // position:"absolute", 
    // bottom:15
  },
  arrows: {
    // marginRight: 100
  },
});

// export default Cart;

function mapStateToProps(state) {
  return {
    rtlCustomer: state.theme.rtlCustomer,
    cartList: state.cart.cartList,
    userDetails: state.auth.userDetails,
  };
}

export default connect(mapStateToProps, {
  deleteProductFromCart,
  updateCartAmount,
})(Cart);
