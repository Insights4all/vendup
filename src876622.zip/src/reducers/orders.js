import {
  ORDERS_LOADING,
  ORDERS_SET_DATA,
  ORDERS_SET_DETAIL,
  ORDERS_SET_ERROR,
  ORDERS_APPLY_FILTER,
  ORDERS_SET_FILTERS,
  ORDERS_RESET_FILTERS,
  ORDERS_SEARCH,
} from '../constants/orders';

const INITIAL_STATE = {
  loading: false,
  orders: [],
  ordersDup: [],
  order: {},
  error: {},
  filters: {
    orderNo: '',
    orderFrom: '',
    startDate: '',
    endDate: '',
    status: '',
  },
};

export default function (state = INITIAL_STATE, action) {
  switch (action.type) {
    case ORDERS_LOADING:
      return {
        ...state,
        loading: action.payload,
      };
    case ORDERS_SET_DATA:
      return {
        ...state,
        orders: action.payload,
        ordersDup: action.payload,
      };
    case ORDERS_SET_DETAIL:
      return {
        ...state,
        order: action.payload,
      };
    case ORDERS_SET_ERROR:
      return {
        ...state,
        error: action.payload,
      };
    case ORDERS_SET_FILTERS: {
      return {
        ...state,
        filters: action.payload,
      };
    }
    case ORDERS_SEARCH: {
      let results = state.ordersDup;
      let resultsOrderNo = [],
        resultsVendor = [],
        resultsStatus = [];

      resultsOrderNo = results.filter((order) =>
        String(order._id).includes(action.payload.searchTerm),
      );

      if (action.payload.role === 'VENDOR') {
        resultsVendor = results.filter((order) =>
          order.customerId.name
            .toLowerCase()
            .includes(action.payload.searchTerm.toLowerCase()),
        );
      } else {
        resultsVendor = results.filter((order) =>
          order.vendorId.name
            .toLowerCase()
            .includes(action.payload.searchTerm.toLowerCase()),
        );
      }
      resultsStatus = results.filter((order) =>
        order.orderStatus
          .toLowerCase()
          .includes(action.payload.searchTerm.toLowerCase()),
      );

      if (resultsOrderNo.length) results = resultsOrderNo;
      else if (resultsVendor.length) results = resultsVendor;
      else if (resultsStatus.length) results = resultsStatus;
      else results = [];

      return {
        ...state,
        orders: action.payload.searchTerm ? results : state.ordersDup,
      };
    }
    case ORDERS_APPLY_FILTER: {
      let results = state.ordersDup;
      if (action.payload.orderNo) {
        results = results.filter((order) =>
          String(order._id).includes(action.payload.orderNo),
        );
      }
      if (action.payload.role === 'VENDOR') {
        if (action.payload.orderFrom) {
          results = results.filter((order) =>
            order.customerId.name
              .toLowerCase()
              .includes(action.payload.orderFrom.toLowerCase()),
          );
        }
      } else {
        if (action.payload.orderFrom) {
          results = results.filter((order) =>
            order.vendorId.name
              .toLowerCase()
              .includes(action.payload.orderFrom.toLowerCase()),
          );
        }
      }
      if (action.payload.status) {
        results = results.filter(
          (order) =>
            action.payload.status.includes(order.orderStatus.toLowerCase()),
        );
      }
      if (action.payload.startDate) {
        results = results.filter(
          (order) =>
            new Date(order.createdAt) >= new Date(action.payload.startDate),
        );
      }
      if (action.payload.endDate) {
        results = results.filter(
          (order) =>
            new Date(order.createdAt) <= new Date(action.payload.endDate),
        );
      }
      return {
        ...state,
        orders: results,
      };
    }
    case ORDERS_RESET_FILTERS: {
      return {
        ...state,
        filters: {
          orderNo: '',
          orderFrom: '',
          startDate: new Date(Date.now()),
          endDate: new Date(Date.now()),
          status: '',
        },
        orders: [...state.ordersDup],
      };
    }
    default:
      return state;
  }
}
