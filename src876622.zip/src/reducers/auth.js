import {
  USER_LOGGED_IN,
  AUTH_SUCCESS,
  AUTH_LOGOUT,
  AUTH_LOADING,
  AUTH_ROLE,
} from '../constants/auth';

const INITIAL_STATE = {
  isLogin: false,
  loading: false,
  token: null,
  role: '',
  userDetails:{}
};

export default function (state = INITIAL_STATE, action) {
  switch (action.type) {
    case AUTH_ROLE:
      return {
        ...state,
        role: action.payload,
      };
    case USER_LOGGED_IN:
      return {
        ...state,
        isLogin: action.payload,
      };
    case AUTH_LOADING:
      return {
        ...state,
        loading: action.payload,
      };
    case AUTH_SUCCESS:
      return {
        ...state,
        token: action.payload.jwtToken,
        role: action.payload.role,
        userDetails: action.payload.userDetails,
        isLogin: true,
      };
    case AUTH_LOGOUT:
      return {
        ...state,
        token: null,
        role: '',
        userDetails: {},
        isLogin: false,
      };
    default:
      return state;
  }
}
