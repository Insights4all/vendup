import {
    PRODUCTS_LOADING,
    PRODUCTS_SET_DATA,
    PRODUCTS_SET_DETAIL,
    PRODUCTS_SET_ERROR,
    PRODUCTS_APPLY_FILTER,
    PRODUCTS_SET_FILTERS,
    PRODUCTS_RESET_FILTERS,
    PRODUCTS_SEARCH
  } from '../constants/products';
  import { productService } from '../service/productService';
  import {SetAuthLogout} from "./auth";

  export const setData = (data) => ({
    type: PRODUCTS_SET_DATA,
    payload: data,
  });
  export const setLoading = status => ({
    type: PRODUCTS_LOADING,
    payload: status
  });
  export const setError = data => ({
    type: PRODUCTS_SET_ERROR,
    payload: data
  });
  export const setDetail = (data) => ({
    type: PRODUCTS_SET_DETAIL,
    payload: data,
  });
  export const applyFilter = (data) => async (dispatch) => {
    dispatch({
      type: PRODUCTS_APPLY_FILTER,
      payload: data,
    })
  }
  export const setFilters = (data) => ({
    type: PRODUCTS_SET_FILTERS,
    payload: data,
  });
  export const resetFilters = (data) => ({
    type: PRODUCTS_RESET_FILTERS,
    payload: data,
  });
  export const searchProducts = (data) => async (dispatch) => {
    dispatch({
      type: PRODUCTS_SEARCH,
      payload: data
    })
  }
  export const fetchProducts = () => async(dispatch) => {
    return new Promise(async(resolve, reject) => {
      await dispatch(setLoading(true));
      productService.fetchProducts().then(async (res) => {
        await dispatch(setData(res));
        resolve(res);
      }).catch((err) => {
        if(err.response.status === 500){
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err))
        reject(err)
      }).finally(()=>{
        dispatch(setLoading(false));
      })
    })
  };
  export const fetchProductDetails = (id) => async(dispatch) => {
    return new Promise(async(resolve, reject) => {
      await dispatch(setLoading(true));
      productService.fetchProductDetails(id).then(async (res) => {
        await dispatch(setDetail(res));
        resolve(res);
      }).catch((err) => {
        if(err.response.status === 500){
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err))
        reject(err)
      }).finally(()=>{
        dispatch(setLoading(false));
      })
    })
  };
  export const deleteProduct = (id) => async (dispatch) => {
    return new Promise(async (resolve, reject) => {
      await dispatch(setLoading(true));
      productService
      .deleteProduct(id)
      .then(async (res) => {
        await dispatch(fetchProducts());
        resolve(res);
      })
      .catch((err) => {
        if (err.response.status === 500) {
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err));
        reject(err);
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
    });
  };
  export const createProduct = (formData) => async (dispatch) => {
    return new Promise(async (resolve, reject) => {
      await dispatch(setLoading(true));
      productService
      .createProduct(formData)
      .then(async (res) => {
        dispatch(fetchProducts());
        resolve(res);
      })
      .catch((err) => {
        if (err.response.status === 500) {
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err));
        reject(err);
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
    });
  };
  export const updateProduct = (formData) => async (dispatch) => {
    return new Promise(async (resolve, reject) => {
      await dispatch(setLoading(true));
      productService
      .updateProduct(formData)
      .then(async (res) => {
        dispatch(fetchProducts());
        resolve(res);
      })
      .catch((err) => {
        if (err.response.status === 500) {
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err));
        reject(err);
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
    });
  };