import {
  ORDERS_LOADING,
  ORDERS_SET_DATA,
  ORDERS_SET_DETAIL,
  ORDERS_SET_ERROR,
  ORDERS_APPLY_FILTER,
  ORDERS_SET_FILTERS,
  ORDERS_RESET_FILTERS,
  ORDERS_SEARCH
} from '../constants/orders';
import {orderService} from '../service/orderService';
import {SetAuthLogout} from './auth';
import {sortArray} from "../utils/";
import {clearProductCart} from "./cart";

export const setData = (data) => ({
  type: ORDERS_SET_DATA,
  payload: data,
});
export const setLoading = (status) => ({
  type: ORDERS_LOADING,
  payload: status,
});
export const setError = (data) => ({
  type: ORDERS_SET_ERROR,
  payload: data,
});
export const setDetail = (data) => ({
  type: ORDERS_SET_DETAIL,
  payload: data,
});
export const applyFilter = (data) => async (dispatch, getState) => {
  let {auth} = getState();
  dispatch({
    type: ORDERS_APPLY_FILTER,
    payload: {...data, role: auth.role},
  })
}
export const setFilters = (data) => ({
  type: ORDERS_SET_FILTERS,
  payload: data,
});
export const resetFilters = (data) => ({
  type: ORDERS_RESET_FILTERS,
  payload: data,
});
export const searchOrders = (data) => async (dispatch, getState) => {
  let {auth} = getState();
  dispatch({
    type: ORDERS_SEARCH,
    payload: {searchTerm: data, role: auth.role},
  })
}
export const fetchVendorOrders = () => async (dispatch) => {
  return new Promise(async (resolve, reject) => {
    await dispatch(setLoading(true));
    orderService
      .fetchVendorOrders()
      .then(async (res) => {
        sortArray(res, "createdAt")
        await dispatch(setData(res));
        resolve(res);
      })
      .catch((err) => {
        if (err.response.status === 500) {
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err));
        reject(err);
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  });
};
export const fetchOrderDetails = (id) => async (dispatch) => {
  return new Promise(async (resolve, reject) => {
    await dispatch(setLoading(true));
    orderService
      .fetchOrderDetails(id)
      .then(async (res) => {
        await dispatch(setDetail(res));
        resolve(res);
      })
      .catch((err) => {
        if (err.response.status === 500) {
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err));
        reject(err);
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  });
};
export const deleteOrder = (id) => async (dispatch) => {
  return new Promise(async (resolve, reject) => {
    await dispatch(setLoading(true));
    orderService
      .deleteOrder(id)
      .then(async (res) => {
        await dispatch(fetchVendorOrders());
        resolve(res);
      })
      .catch((err) => {
        if (err.response.status === 500) {
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err));
        reject(err);
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  });
};
export const changeOrderStatus = (formData) => async (dispatch) => {
  return new Promise(async (resolve, reject) => {
    await dispatch(setLoading(true));
    orderService
      .changeOrderStatus(formData)
      .then(async (res) => {
        await dispatch(fetchOrderDetails(formData.orderId));
        resolve(res);
      })
      .catch((err) => {
        if (err.response.status === 500) {
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err));
        reject(err);
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  });
};
export const fetchCustomerOrders = () => async (dispatch) => {
  return new Promise(async (resolve, reject) => {
    await dispatch(setLoading(true));
    orderService
    .fetchCustomerOrders()
    .then(async (res) => {
      sortArray(res, "createdAt")
      await dispatch(setData(res));
      resolve(res);
    })
    .catch((err) => {
      if (err.response.status === 500) {
        dispatch(SetAuthLogout());
      }
      dispatch(setError(err));
      reject(err);
    })
    .finally(() => {
      dispatch(setLoading(false));
    });
  });
};
export const placeOrder = (formData) => async (dispatch) => {
  return new Promise(async (resolve, reject) => {
    await dispatch(setLoading(true));
    orderService
      .placeOrder(formData)
      .then(async (res) => {
        await dispatch(clearProductCart());
        resolve(res);
      })
      .catch((err) => {
        if (err.response.status === 500) {
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err));
        reject(err);
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  });
};