import {RTL_CUSTOMER, RTL_VENDOR, LANG_VENDOR, LANG_CUSTOMER, RESET_THEME} from '../constants/theme';

export const setRTLCUSTOMER = (rtl) => ({
    type: RTL_CUSTOMER,
    payload: rtl,
  });
  export const setRTLVENDOR = rtl => ({
    type: RTL_VENDOR,
    payload: rtl
  });
  export const setLangCustomer = (data) => ({
    type: LANG_CUSTOMER,
    payload: data,
  });
  export const setLangVendor = (data) => ({
    type: LANG_VENDOR,
    payload: data,
  });
  export const resetTheme = () => ({
    type: RESET_THEME,
  });