export const getProductStatus = (quantity) => {
  if (quantity >= 30)
    return {
      status: 'Available',
      color: 'green',
    };
  else if (quantity < 30 && quantity > 0)
    return {
      status: 'Running Out',
      color: 'secondary',
    };
  else
    return {
      status: 'Stock Out',
      color: 'error',
    };
};
export const sortArray = (array, key) => {
  array.sort(function (a, b) {
    var keyA = new Date(a[key]),
      keyB = new Date(b[key]);
    if (keyA < keyB) return 1;
    if (keyA > keyB) return -1;
    return 0;
  });
}
export const asyncForEach = async(array, callback)=>{
	for (let index = 0; index < array.length; index++) {
		await callback(array[index], index, array);
	}
}
export const paginator =(items, offset, limit)=> {
  let paginatedItems = items.slice(offset).slice(0, limit);
  return {
    data: paginatedItems,
  };
}