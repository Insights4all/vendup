'use strict';
export default {
    // default Shades
    black: '#000',    
    color1: "#222",
    color32: "#323232",
    color2: "#333",
    color3: "#444",
    color4: "#666",
    color5: "#999",
    colora: "#aaa",
    colorb: "#bbb",
    colorc: "#ccc",
    colord: "#ddd",
    colore: "#eee",
    colorfa: "#fafafa",
    colorf8: "#f8f8f8",
    white: '#FFF',

    // White Blue
    whiteBlue1: '#eceff1',
    whiteBlue2: '#cfd8dc',
    whiteBlue3: '#b0bec5',
    whiteBlue4: '#90a4ae',
    whiteBlue5: '#78909c',
    whiteBlue6: '#607d8b',
    whiteBlue7: '#455a64',
    whiteBlue8: '#37474f',
    whiteBlue9: '#263238',

    // Green Shades
    green: '#00e676',
    greenDark: '#2e7d32',
    greenLight: '#81c784',

    // Review Green
    reviewGreen: '#8DB600',

    // Red Shades
    red: '#ff1744',
    redDark: '#d32f2f',
    redLight: '#ef9a9a',

    // megenta
    favRed: '#F46D6D',

    // wine
    wine: '#b11226',

    // Yellow Shades
    yellow: '#ffea00',
    yellowDark: '#f9a825',
    yellowlight: '#ffee58',

    //Gold 
    gold: '#ffb300',
    
    // Blue shades
    blue: '#03a9f4',
    blueDark: '#0277bd',
    blueLight: "#40c4ff",
    blueRaw: '#0000FF',

    // font
    font: '#3B3B3B',

    // transparent
    transparent: '#0000',

    // muted
    muted: '#aaa',
  };
  