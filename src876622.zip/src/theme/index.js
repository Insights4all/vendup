'use strict';
import Colors from './colors';
import Fonts from './fonts';

export {Colors, Fonts};
