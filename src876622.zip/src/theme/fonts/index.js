'use strict';
export default {
  // font size
  font8: 8,
  font9: 9,
  font10: 10,
  font11: 11,
  font12: 12,
  font14: 14,
  fontDefault: 15,
  font16: 16,
  font18: 18,
  font20: 20,
  font25: 25,
  font28: 28,
  font30: 30,
  // font Family
  fontRoboto: 'Roboto',
  fontRobotoSL: 'Roboto-Thin',
  fontRobotoL: 'Roboto-Light',
  fontRobotoSB: 'Roboto-Black',
  fontRobotoB: 'Roboto-Bold',
  fontRobotoM: 'Roboto-medium',
};
