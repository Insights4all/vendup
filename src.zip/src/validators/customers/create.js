import validator from 'validator';
import isEmpty from '../isEmpty';
const validateCreateCustomer = (data) => {
  let errors = {};

  data.firstName = !isEmpty(data.firstName) ? data.firstName.trim() : '';
  data.lastName = !isEmpty(data.lastName) ? data.lastName.trim() : '';
  data.email = !isEmpty(data.email) ? data.email.trim() : '';
  data.password = !isEmpty(data.password) ? data.password : '';
  data.phoneNumber = !isEmpty(data.phoneNumber) ? data.phoneNumber.trim() : '';
  data.companyName = !isEmpty(data.companyName) ? data.companyName.trim() : '';
  data.percentDiscount = !isEmpty(data.percentDiscount)
    ? String(data.percentDiscount).trim()
    : '';
  data.id = !isEmpty(data.id) ? data.id : '';

  if (validator.isEmpty(data.firstName)) {
    errors.firstName = 'First name is required';
  }
  if (validator.isEmpty(data.firstName)) {
    errors.lastName = 'Last name is required';
  }
  if (!validator.isEmail(data.email)) {
    errors.email = 'Enter valid email';
  }
  if (validator.isEmpty(data.email)) {
    errors.email = 'Email is required';
  }
  if (validator.isEmpty(data.id)) {
    if (validator.isEmpty(data.password)) {
      errors.password = 'Password is required';
    }
  }
  if (validator.isEmpty(data.phoneNumber)) {
    errors.phoneNumber = 'Phone is required';
  }
  if (validator.isEmpty(data.companyName)) {
    errors.companyName = 'Company is required';
  }
  if (validator.isEmpty(data.percentDiscount)) {
    errors.percentDiscount = 'Discount is required';
  }

  return {
    errors,
    isValid: isEmpty(errors),
  };
};

export default validateCreateCustomer;
