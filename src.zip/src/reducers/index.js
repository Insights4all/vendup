import {combineReducers} from 'redux';
import authReducer from './auth';
import orderReducer from './orders';
import customerReducer from './customers';
import shopReducer from './shop';
import productReducer from './products';
import cartReducer from './cart';
import themeReducer from './theme';

const rootReducer = combineReducers({
  auth: authReducer,
  orders: orderReducer,
  customers: customerReducer,
  shop: shopReducer,
  products: productReducer,
  cart: cartReducer,
  theme: themeReducer
});

export default rootReducer;
