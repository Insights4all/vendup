import {
  SHOP_LOADING,
  SHOP_SET_DATA,
  SHOP_SET_DETAIL,
  SHOP_SET_ERROR,
  SHOP_SET_VENDORS,
  SHOP_SEARCH_PRODUCT,
  SHOP_FILTER_PRODUCTS,
  SHOP_SET_FILTERS,
  SHOP_RESET_FILTERS,
  setActiveVendorId,
  SHOP_SET_ACTIVE_VENDOR_ID,
} from '../constants/shop';
import {filter} from 'lodash';

const INITIAL_STATE = {
  loading: false,
  products: [],
  productsDup: [],
  product: {},
  error: {},
  vendors: [],
  filters: {
    maxPrice: '',
    minPrice: '',
    selectedCategory: [],
    selectedSubCategory: [],
    isSpecial: false,
  },
  activeVendorId: 0,
};

export default function (state = INITIAL_STATE, action) {
  switch (action.type) {
    case SHOP_LOADING:
      return {
        ...state,
        loading: action.payload,
      };
    case SHOP_SET_DATA:
      return {
        ...state,
        products: action.payload,
        productsDup: action.payload,
      };
    case SHOP_SET_DETAIL:
      return {
        ...state,
        product: action.payload,
      };
    case SHOP_SET_ERROR:
      return {
        ...state,
        error: action.payload,
      };
    case SHOP_SET_VENDORS:
      return {
        ...state,
        vendors: action.payload,
      };
    case SHOP_SET_ACTIVE_VENDOR_ID:
      return {
        ...state,
        activeVendorId: action.payload,
      };
    case SHOP_SEARCH_PRODUCT: {
      let results = filter(state.productsDup, function (item) {
        return item.productName.indexOf(action.payload) > -1;
      });
      console.log(results.length);
      return {
        ...state,
        products: results,
      };
    }
    case SHOP_SET_FILTERS: {
      return {
        ...state,
        filters: action.payload,
      };
    }
    case SHOP_RESET_FILTERS: {
      return {
        ...state,
        filters: {
          maxPrice: '',
          minPrice: '',
          selectedCategory: [],
          selectedSubCategory: [],
          isSpecial: false,
        },
      };
    }
    case SHOP_FILTER_PRODUCTS: {
      let results = state.productsDup;
      if (action.payload.minPrice) {
        results = results.filter(
          (product) => product.price <= action.payload.minPrice,
        );
      }
      if (action.payload.maxPrice) {
        results = results.filter(
          (product) => product.price >= action.payload.maxPrice,
        );
      }
      if (action.payload.selectedCategory.length) {
        results = results.filter((product) =>
          action.payload.selectedCategory.includes(product.category),
        );
      }
      if (action.payload.selectedSubCategory.length) {
        results = results.filter((product) =>
          action.payload.selectedSubCategory.includes(product.subCategory),
        );
      }
      if (action.payload.isSpecial) {
        results = results.filter((product) => product.specialPrice > 0 && product.isSpecial);
      }
      return {
        ...state,
        products: results,
      };
    }
    default:
      return state;
  }
}
