import {
  CUSTOMERS_LOADING,
  CUSTOMERS_SET_DATA,
  CUSTOMERS_SET_ERROR,
  CUSTOMERS_APPLY_FILTER,
  CUSTOMERS_SET_FILTERS,
  CUSTOMERS_RESET_FILTERS,
  CUSTOMERS_SEARCH,
} from '../constants/customers';

const INITIAL_STATE = {
  loading: false,
  customers: [],
  customersDup: [],
  error: {},
  filters: {
    name: '',
    email: '',
    phone: '',
    company: '',
    discount: '',
  },
};

export default function (state = INITIAL_STATE, action) {
  switch (action.type) {
    case CUSTOMERS_LOADING:
      return {
        ...state,
        loading: action.payload,
      };
    case CUSTOMERS_SET_DATA:
      return {
        ...state,
        customers: action.payload,
        customersDup: action.payload,
      };
    case CUSTOMERS_SET_ERROR:
      return {
        ...state,
        error: action.payload,
      };
    case CUSTOMERS_SET_FILTERS: {
      return {
        ...state,
        filters: action.payload,
      };
    }
    case CUSTOMERS_SEARCH: {
      let results = state.customersDup;
      let resultsName = [],
        resultsEmail = [],
        resultsPhone = [],
        resultsCompany = [],
        resultsDiscount = [];

      resultsName = results.filter((customer) =>
        `${customer.firstName} ${customer.lastName}`
          .toLowerCase()
          .includes(action.payload.toLowerCase()),
      );
      resultsEmail = results.filter((customer) =>
        customer.customerId.email
          .toLowerCase()
          .includes(action.payload.toLowerCase()),
      );
      resultsPhone = results.filter((customer) =>
        customer.phoneNumber
          .toLowerCase()
          .includes(action.payload.toLowerCase()),
      );
      resultsCompany = results.filter((customer) =>
        customer.companyName
          .toLowerCase()
          .includes(action.payload.toLowerCase()),
      );
      resultsDiscount = results.filter((customer) =>
        String(customer.percentDiscount).includes(action.payload),
      );
      if (resultsName.length) results = resultsName;
      else if (resultsEmail.length) results = resultsEmail;
      else if (resultsPhone.length) results = resultsPhone;
      else if (resultsCompany.length) results = resultsCompany;
      else if (resultsDiscount.length) results = resultsDiscount;
      else results = [];

      return {
        ...state,
        customers: action.payload ? results : state.customersDup,
      };
    }
    case CUSTOMERS_APPLY_FILTER: {
      let results = state.customersDup;

      if (action.payload.name) {
        results = results.filter((customer) =>
          `${customer.firstName} ${customer.lastName}`
            .toLowerCase()
            .includes(action.payload.name.toLowerCase()),
        );
      }
      if (action.payload.email) {
        results = results.filter((customer) =>
          customer.customerId.email
            .toLowerCase()
            .includes(action.payload.email.toLowerCase()),
        );
      }
      if (action.payload.phone) {
        results = results.filter((customer) =>
          customer.phoneNumber
            .toLowerCase()
            .includes(action.payload.phone.toLowerCase()),
        );
      }
      if (action.payload.company) {
        results = results.filter((customer) =>
          customer.companyName
            .toLowerCase()
            .includes(action.payload.company.toLowerCase()),
        );
      }
      if (action.payload.discount) {
        results = results.filter((customer) =>
          String(customer.percentDiscount).includes(action.payload.discount),
        );
      }
      return {
        ...state,
        customers: results,
      };
    }
    case CUSTOMERS_RESET_FILTERS: {
      return {
        ...state,
        filters: {
          name: '',
          email: '',
          phone: '',
          company: '',
          discount: '',
        },
        customers: [...state.customersDup],
      };
    }
    default:
      return state;
  }
}
