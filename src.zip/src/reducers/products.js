import {
  PRODUCTS_LOADING,
  PRODUCTS_SET_DATA,
  PRODUCTS_SET_DETAIL,
  PRODUCTS_SET_ERROR,
  PRODUCTS_APPLY_FILTER,
  PRODUCTS_SET_FILTERS,
  PRODUCTS_RESET_FILTERS,
  PRODUCTS_SEARCH,
} from '../constants/products';

const INITIAL_STATE = {
  loading: false,
  products: [],
  productsDup: [],
  product: {},
  error: {},
  filters: {
    name: '',
    category: '',
    subCategory: '',
    price: '',
    quantity: '',
    minMax: '',
  },
};

export default function (state = INITIAL_STATE, action) {
  switch (action.type) {
    case PRODUCTS_LOADING:
      return {
        ...state,
        loading: action.payload,
      };
    case PRODUCTS_SET_DATA:
      return {
        ...state,
        products: action.payload,
        productsDup: action.payload,
      };
    case PRODUCTS_SET_DETAIL:
      return {
        ...state,
        product: action.payload,
      };
    case PRODUCTS_SET_ERROR:
      return {
        ...state,
        error: action.payload,
      };
    case PRODUCTS_SET_FILTERS: {
      return {
        ...state,
        filters: action.payload,
      };
    }
    case PRODUCTS_SEARCH: {
      let results = state.productsDup;
      let resultsName = [],
        resultsCategory = [],
        resultsSubCategory = [],
        resultsPrice = [],
        resultsQuantity = [],
        resultsMinMax = [];

      resultsName = results.filter((product) =>
        product.productName
          .toLowerCase()
          .includes(action.payload.toLowerCase()),
      );
      resultsCategory = results.filter((product) =>
        product.category.toLowerCase().includes(action.payload.toLowerCase()),
      );
      resultsSubCategory = results.filter((product) =>
        product.subCategory
          .toLowerCase()
          .includes(action.payload.toLowerCase()),
      );
      resultsPrice = results.filter((product) =>
        String(product.price)
          .toLowerCase()
          .includes(action.payload.toLowerCase()),
      );
      resultsQuantity = results.filter((product) =>
        String(product.quantity).includes(action.payload),
      );
      resultsMinMax = results.filter((product) =>
        `${product.minOrderQuantity}/${product.maxOrderQuantity}`.includes(
          action.payload,
        ),
      );
      if (resultsName.length) results = resultsName;
      else if (resultsCategory.length) results = resultsCategory;
      else if (resultsSubCategory.length) results = resultsSubCategory;
      else if (resultsPrice.length) results = resultsPrice;
      else if (resultsQuantity.length) results = resultsQuantity;
      else if (resultsMinMax.length) results = resultsMinMax;
      else results = [];

      return {
        ...state,
        products: action.payload ? results : state.productsDup,
      };
    }
    case PRODUCTS_APPLY_FILTER: {
      let results = state.productsDup;

      if (action.payload.name) {
        results = results.filter((product) =>
          product.productName
            .toLowerCase()
            .includes(action.payload.name.toLowerCase()),
        );
      }
      if (action.payload.category) {
        results = results.filter((product) =>
          product.category
            .toLowerCase()
            .includes(action.payload.category.toLowerCase()),
        );
      }
      if (action.payload.subCategory) {
        results = results.filter((product) =>
          product.subCategory
            .toLowerCase()
            .includes(action.payload.subCategory.toLowerCase()),
        );
      }
      if (action.payload.price) {
        results = results.filter((product) =>
          String(product.price)
            .toLowerCase()
            .includes(action.payload.price.toLowerCase()),
        );
      }
      if (action.payload.quantity) {
        results = results.filter((product) =>
          String(product.quantity).includes(action.payload.quantity),
        );
      }
      if (action.payload.minMax) {
        results = results.filter((product) =>
          `${product.minOrderQuantity}/${product.maxOrderQuantity}`.includes(
            action.payload.minMax,
          ),
        );
      }
      return {
        ...state,
        products: results,
      };
    }
    case PRODUCTS_RESET_FILTERS: {
      return {
        ...state,
        filters: {
          name: '',
          category: '',
          subCategory: '',
          price: '',
          quantity: '',
          minMax: '',
        },
        products: [...state.productsDup],
      };
    }
    default:
      return state;
  }
}
