import {RTL_CUSTOMER, RTL_VENDOR, LANG_VENDOR, LANG_CUSTOMER, RESET_THEME} from '../constants/theme';

const INITIAL_STATE = {
  rtlVendor: false,
  langVendor: "enUS",
  rtlCustomer: false,
  langCustomer: "enUS",
};

export default function (state = INITIAL_STATE, action) {
  switch (action.type) {
    case RTL_VENDOR:
      return {
        ...state,
        rtlVendor: action.payload,
      };
    case RTL_CUSTOMER:
      return {
        ...state,
        rtlCustomer: action.payload,
      };
    case LANG_VENDOR:
      return {
        ...state,
        langVendor: action.payload
      };
    case LANG_CUSTOMER:
      return {
        ...state,
        langCustomer: action.payload
      };
    case RESET_THEME:
      return {
        ...state,
        rtlVendor: false,
        langVendor: "enUS",
        rtlCustomer: false,
        langCustomer: "enUS",
      }
    default:
      return state;
  }
}
