import React, {useEffect} from 'react';
import {TouchableOpacity, View, Text, StyleSheet} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import {connect} from 'react-redux';

const CheckBox = (props) => {
  const [checked, setChecked] = React.useState(props.checked);
  const rtl = props.scope === "customer" ? props.rtlCustomer : props.rtlVendor;
  useEffect(() => {
    setChecked(props.checked);
  }, [props.checked])
  return (
    <TouchableOpacity
      style={[
        styles.checkboxContainer,
        {flexDirection: rtl ? 'row-reverse' : 'row'},
      ]}
      onPress={() => {
        setChecked(!checked);
        props.onChange(!checked, props.text);
      }}>
      <View
        style={{
          width: 20,
          height: 20,
          marginVertical: 5,
          borderWidth: 1,
          borderRadius: 3,
          marginRight: 10,
        }}>
        {checked && <Feather name="check" size={18} color="#000" />}
      </View>
      <Text style={styles.chechTxt}>{props.text}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  checkboxContainer: {
    flexDirection: 'row',
    // marginBottom: 20,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  chechTxt:  {
    margin: 8
  }
});

function mapStateToProps(state) {
  return {
    rtlCustomer: state.theme.rtlCustomer,
    rtlVendor: state.theme.rtlVendor,
  };
}

export default connect(mapStateToProps, {})(CheckBox);