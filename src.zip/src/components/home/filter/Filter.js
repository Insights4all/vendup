import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TextInput,
  TouchableOpacity,
  // CheckBox,
  ScrollView,
  Platform,
} from 'react-native';
import { useTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import { filterProduct, setFilters, resetFilters } from '../../../actions/shop';
// import Feather from 'react-native-vector-icons/Feather';
import Icons from 'react-native-vector-icons/MaterialIcons';
const Window = Dimensions.get('window');
import CheckBox from '../../CheckBox';

const isIos = Platform.OS === 'ios';

const Filter = (props) => {
  const { t } = useTranslation();
  const rtl = props.rtlCustomer;
  const checked = false;
  const [categoryList, setCategoryList] = useState({});
  const handleCategoryChange = (checked, cat) => {
    let oldCats = props.filters.selectedCategory;
    let oldSubCats = props.filters.selectedSubCategory;
    if (checked) {
      Object.keys(categoryList[cat]).map((subcat) => {
        oldSubCats.push(subcat);
      });
      oldCats.push(cat);
      props.setFilters({
        ...props.filters,
        selectedCategory: [...oldCats],
        selectedSubCategory: [...oldSubCats],
      });
    } else {
      let subCats = [];
      Object.keys(categoryList[cat]).map((subcat) => {
        subCats.push(subcat);
      });
      oldSubCats = oldSubCats.filter((el) => !subCats.includes(el));
      oldCats = oldCats.filter((cat_) => cat_ !== cat);
      props.setFilters({
        ...props.filters,
        selectedCategory: [...oldCats],
        selectedSubCategory: [...oldSubCats],
      });
    }
  };
  const handleSubCategoryChange = (checked, cat) => {
    let oldSubCats = props.filters.selectedSubCategory;
    if (checked) {
      oldSubCats.push(cat);
      props.setFilters({
        ...props.filters,
        selectedSubCategory: [...oldSubCats],
      });
    } else {
      oldSubCats = oldSubCats.filter((cat_) => cat_ !== cat);
      props.setFilters({
        ...props.filters,
        selectedSubCategory: [...oldSubCats],
      });
    }
  };
  const handleApplyFilter = async () => {
    await props.filterProduct(props.filters);
    props.onClose();
  };
  const handleResetFilter = async() =>{
    props.resetFilters();
    props.filterProduct({
      maxPrice: '',
      minPrice: '',
      selectedCategory: [],
      selectedSubCategory: [],
      isSpecial: false,
    });
    props.onClose();
  }
  useEffect(() => {
    let cat = '';
    let subCat = '';
    const categoryObject = {};
    let singleCat = {};
    let singleSubCat = {};
    props.products.forEach((product) => {
      cat = product.category;
      subCat = product.subCategory;
      singleCat = categoryObject[cat] || {};
      if (subCat) {
        singleSubCat = singleCat[subCat] || 0;
        singleCat[subCat] = singleSubCat + 1;
      }
      categoryObject[cat] = singleCat;
    });
    setCategoryList(categoryObject);
  }, [props.products]);
  // console.log(props.filters.selectedSubCategory);
  return (
    <View style={styles.filterSideNav}>
      <View style={styles.sidenavInner}>
        {/* <View style={[styles.searchWrapper, {flexDirection: rtl ? 'row-reverse' : 'row'}]}>
          <Icon name="search" size={18} color={'#aaa'} />
          <TextInput placeholder={t('Search here')} style={styles.inputSearch} />
        </View> */}
        <View style={styles.allProductsWrapper}>
          <TouchableOpacity
            style={styles.flatbtn}
            onPress={() => handleResetFilter()}>
            <Text style={[styles.btnText, { color: '#ffff' }]}>
              {t('All Products')}
            </Text>
          </TouchableOpacity>
        </View>
        <View style={{ flex: 1 }}>
          <View style={styles.sidenavInner}>
            <View style={{ height: 20 }} />
            {/* <View style={styles.card}>
              <Text>{t('Price')}</Text>
              <View
                style={[
                  styles.row,
                  {flexDirection: rtl ? 'row-reverse' : 'row'},
                ]}>
                <View style={styles.col}>
                  <View style={styles.searchWrapper}>
                    <TextInput
                      placeholder={t('Max Price')}
                      style={[styles.inputSearch, {marginLeft: 0}]}
                      value={props.filters.maxPrice}
                      onChangeText={(value) =>
                        props.setFilters({...props.filters, maxPrice: value})
                      }
                    />
                  </View>
                </View>
                <View style={styles.col}>
                  <View style={styles.searchWrapper}>
                    <TextInput
                      placeholder={t('Min Price')}
                      style={[styles.inputSearch, {marginLeft: 0}]}
                      value={props.filters.minPrice}
                      onChangeText={(value) =>
                        props.setFilters({...props.filters, minPrice: value})
                      }
                    />
                  </View>
                </View>
              </View>
            </View> */}
            {/* <View style={styles.card}>
              <TouchableOpacity
                style={[styles.specialBtn, {backgroundColor: props.filters.isSpecial ? "#d0b422" : "#f0dc82"}]}
                onPress={() => {
                  props.setFilters({
                    ...props.filters,
                    isSpecial: !props.filters.isSpecial,
                  });
                }}>
                <Icons name={props.filters.isSpecial ? "star" : "star-border"} size={18} color="#fff" />
                <Text style={[styles.btnText, {color: '#ffff', marginLeft: 5}]}>
                  {t('Special')}
                </Text>
              </TouchableOpacity>
            </View> */}
            <View style={styles.card}>
              <Text>{t('Category')}</Text>
              <ScrollView
                style={{
                  width: '98%',
                  height: '60%',
                  // marginRight: -20
                }}>
                {Object.keys(categoryList).map((category) => (
                  <>
                    <CheckBox
                      checked={props.filters.selectedCategory.includes(
                        category,
                      )}
                      text={category}
                      onChange={(value) =>
                        handleCategoryChange(value, category)
                      }
                      scope={props.scope}
                    />
                    <View style={rtl || props.rtlVendor ? { marginRight: 15 } : { marginLeft: 15 }}>
                      {Object.keys(categoryList[category]).map((subcat) => (
                        <>
                          <CheckBox
                            checked={props.filters.selectedSubCategory.includes(
                              subcat,
                            )}
                            text={subcat}
                            onChange={(value) =>
                              handleSubCategoryChange(value, subcat)
                            }
                            scope={props.scope}
                          />
                        </>
                      ))}
                    </View>
                  </>
                ))}
                {/* {[...new Set(props.products.map((item) => item.category))].map(
                  (category, i) => (
                    <>
                      <CheckBox
                        checked={props.filters.selectedCategory.includes(
                          category,
                        )}
                        text={category}
                        onChange={(value) =>
                          handleCategoryChange(value, category)
                        }
                        scope={props.scope}
                      />
                      <View style={{marginLeft: 15}} >
                        {[
                          ...new Set(
                            props.products.map((item) => item.subCategory),
                          ),
                        ].map((subCategory, i) => (
                          <>
                            <CheckBox
                              checked={props.filters.selectedSubCategory.includes(
                                subCategory,
                              )}
                              text={subCategory}
                              onChange={(value) =>
                                handleSubCategoryChange(value, subCategory)
                              }
                              scope={props.scope}
                            />
                          </>
                        ))}
                      </View>
                    </>
                  ),
                )} */}
              </ScrollView>
            </View>
            {/* <View style={styles.card}>
              <Text>{t('Sub Category')}</Text>
              <ScrollView
                style={{
                  height: '25%',
                  width: '98%',
                  // marginRight: -20
                }}>
                {[
                  ...new Set(props.products.map((item) => item.subCategory)),
                ].map((subCategory, i) => (
                  <>
                    <CheckBox
                      checked={props.filters.selectedSubCategory.includes(
                        subCategory,
                      )}
                      text={subCategory}
                      onChange={(value) =>
                        handleSubCategoryChange(value, subCategory)
                      }
                      scope={props.scope}
                    />
                  </>
                ))}
              </ScrollView>
            </View> */}
          </View>
        </View>
        <View
          style={[
            styles.row,
            {
              flexDirection: rtl ? 'row-reverse' : 'row',
              marginBottom: isIos ? 60 : 10,
            },
          ]}>
          <View style={styles.col}>
            <TouchableOpacity
              style={styles.btn}
              onPress={() => handleApplyFilter()}>
              <Text style={[styles.btnText, { color: '#ffff' }]}>
                {t('Apply')}
              </Text>
            </TouchableOpacity>
          </View>
          <View style={styles.col}>
            <TouchableOpacity
              style={[styles.btnOutline, { marginLeft: 14 }]}
              onPress={props.onClose}>
              <Text style={[styles.btnOutlineText, { textAlign: 'left' }]}>
                {t('Cancel')}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <TouchableOpacity
        style={styles.sidenavClose}
        onPress={props.onClose}></TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  filterSideNav: {
    flex: 1,
    position: 'absolute',
    top: 0,
    left: 0,
    backgroundColor: '#f000',
    width: Window.width,
    height: Window.height,
    zIndex: 999,
    elevation: 20,
    flexDirection: 'row',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  sidenavInner: {
    width: 300,
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    backgroundColor: '#fafafa',
    height: '100%',
    // elevation: 50,
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingBottom: 20,
  },
  sidenavClose: {
    width: 500,
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    backgroundColor: '#000c',
    height: '100%',
  },
  searchWrapper: {
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#aaaa',
    paddingLeft: 10,
    borderRadius: 5,
    backgroundColor: '#fff',
  },
  inputSearch: {
    backgroundColor: '#0000',
    height: 35,
    marginLeft: 10,
    width: '85%',
  },
  card: {
    elevation: 3,
    backgroundColor: '#fff',
    padding: 10,
    width: '94%',
    marginTop: 15,
    borderRadius: 5,
  },
  row: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  col: {
    flex: 1,
    paddingHorizontal: 5,
    paddingVertical: 14,
  },
  checkboxContainer: {
    flexDirection: 'row',
    // marginBottom: 20,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  checkbox: {
    alignSelf: 'center',
  },
  label: {
    margin: 8,
  },
  btn: {
    width: '100%',
    display: 'flex',
    justifyContent: 'center',
    borderWidth: 1,
    borderRadius: 500,
    padding: 10,
  },
  btn: {
    width: '100%',
    display: 'flex',
    justifyContent: 'center',
    // borderWidth: 1,
    borderRadius: 500,
    padding: 10,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#7467EF',
    elevation: 5,
  },
  specialBtn: {
    width: '100%',
    display: 'flex',
    justifyContent: 'center',
    // borderWidth: 1,
    borderRadius: 5,
    padding: 10,
    display: 'flex',
    alignItems: 'center',
    backgroundColor: '#d0b422',
    elevation: 5,
    flexDirection: 'row',
  },
  allProductsWrapper:{
    width: "90%", 
    marginTop: 20
  },
  flatbtn:{
    height: 40,
    display: 'flex',
    justifyContent: 'center',
    // borderWidth: 1,
    borderRadius: 3,
    padding: 7,
    paddingHorizontal: 15,
    display: 'flex',
    alignItems: 'center',
    backgroundColor: '#7467EF',
    elevation: 2,
    flexDirection: 'row',
    marginTop: 15,
  }
});

// export default Filter;

function mapStateToProps(state) {
  return {
    rtlCustomer: state.theme.rtlCustomer,
    rtlVendor: state.theme.rtlVendor,
    products: state.shop.productsDup,
    filters: state.shop.filters,
  };
}

export default connect(mapStateToProps, {
  filterProduct,
  setFilters,
  resetFilters
})(Filter);
