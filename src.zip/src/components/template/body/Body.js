import React from 'react';
import {
  View,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Platform,
} from 'react-native';
import {Colors} from '../../../theme';

const isIos = Platform.os === 'ios';

const Body = (props) => {
  return (
    <SafeAreaView style={styles.container}>
      {/* <StatusBar barStyle="dark-content" backgroundColor="#000" /> */}
      {/* {isIos === true ? (
        <StatusBar />
      ) : (
        <StatusBar barStyle="light-content" backgroundColor="#000" />
      )} */}
      <View style={styles.container}>{props.children}</View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
});

export default Body;
