import React, {useEffect} from 'react';
import {DrawerContentScrollView} from '@react-navigation/drawer';
import {
  View,
  Text,
  Image,
  ImageBackground,
  TouchableOpacity,
  StyleSheet,
  Switch,
  Picker,
  Modal,
  Dimensions,
} from 'react-native';
import Icons from 'react-native-vector-icons/MaterialCommunityIcons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {connect} from 'react-redux';
import {setRTLVENDOR, setLangVendor} from '../actions/theme';

import {setRole, SetAuthLogout} from '../actions/auth';
import {useTranslation} from 'react-i18next';

const Window = Dimensions.get('window');

const CustomDrawerComponentVendor = (props) => {
  const {t, i18n} = useTranslation();

  const [modalVisible, setModalVisible] = React.useState(false);

  const rtl = props.rtlVendor;
  const [menu, setMenu] = React.useState('VOrder');
  const [drop, setDrop] = React.useState(false);

  const vendors = [{name: 'Guy Dhaman'}, {name: 'John Doe'}];
  const logOut = async () => {
    i18n.changeLanguage('enUS');
    await AsyncStorage.setItem('lang', 'enUS');
    await AsyncStorage.removeItem('token');
    await AsyncStorage.removeItem('role');
    props.SetAuthLogout();
  };

  const rtlSet = async (lang) => {
    if (lang === 'enUS') {
      i18n.changeLanguage('enUS');
      await AsyncStorage.setItem('lang', 'enUS');
      props.setRTLVENDOR(false);
      props.setLangVendor('enUS');
    } else if (lang === 'arUA') {
      i18n.changeLanguage('arUA');
      await AsyncStorage.setItem('lang', 'arUA');
      props.setRTLVENDOR(true);
      props.setLangVendor('arUA');
    } else if (lang === 'heIL') {
      i18n.changeLanguage('heIL');
      await AsyncStorage.setItem('lang', 'heIL');
      props.setRTLVENDOR(true);
      props.setLangVendor('heIL');
    }
  };

  return (
    <ImageBackground
      source={require('../assets/sidebar-bg-dark.jpg')}
      style={{flex: 1}}>
      <View style={styles.wrapper}>
        <DrawerContentScrollView {...props}>
          <View style={rtl ? styles.topSectionRTL : styles.topSection}>
            <Image
              source={require('../assets/v2.png')}
              style={rtl ? styles.logoRTL : styles.logo}
            />
            <Text style={styles.header}>Vendup</Text>
          </View>

          {/* <View style={styles.row}>
            <TouchableOpacity
              style={selectedValue === 'en' ? styles.langActive : styles.lang}
              onPress={() => {
                setSelectedValue('en');
              }}>
              <Text style={styles.langText}>EN</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.lang}
              style={selectedValue === 'ar' ? styles.langActive : styles.lang}
              onPress={() => {
                setSelectedValue('ar');
              }}>
              <Text style={styles.langText}>AR</Text>
            </TouchableOpacity>
          </View> */}

          <TouchableOpacity
            style={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              flexDirection: 'row',
              padding: 15,
              marginBottom: 15,
            }}
            onPress={() => {
              setModalVisible(!modalVisible);
            }}>
            {props.langVendor === 'enUS' ? (
              <Text style={{flex: 1, color: '#fff', fontSize: 16}}>En</Text>
            ) : props.langVendor === 'arUA' ? (
              <Text style={{flex: 1, color: '#fff', fontSize: 16}}>Ar</Text>
            ) : (
              <Text style={{flex: 1, color: '#fff', fontSize: 16}}>He</Text>
            )}
            <Icons
              name="chevron-down"
              size={16}
              color="#fff"
              style={styles.logoutButnIcon}
            />
          </TouchableOpacity>

          {/* <Picker
            selectedValue={props.langVendor}
            style={{
              height: 30,
              width: '95%',
              textAlign: 'cneter',
              color: '#fffc',
              marginLeft: 7,
              marginTop: 10,
              marginBottom: 30,
            }}
            onValueChange={(itemValue, itemIndex) => {
              // setSelectedValue(itemValue)
              rtlSet(itemValue);
            }}>
            <Picker.Item label="En" value="enUS" />
            <Picker.Item label="Ar" value="arUA" />
            <Picker.Item label="He" value="heIL" />
          </Picker> */}
          <View style={styles.body}>
            <View style={styles.userSection}>
              <Text
                style={[styles.userName, {textAlign: rtl ? 'right' : 'left'}]}>
                {props.userDetails.firstName} {props.userDetails.lastName}
              </Text>
              <TouchableOpacity
                style={rtl ? styles.logoutButnRTL : styles.logoutButn}
                onPress={() => {
                  logOut();
                  props.navigation.closeDrawer();
                }}>
                <Icons
                  name="logout"
                  size={35}
                  color="#fff"
                  style={styles.logoutButnIcon}
                />
              </TouchableOpacity>
            </View>
            <View style={styles.menu}>
              <TouchableOpacity
                style={[
                  menu === 'VOrder'
                    ? rtl
                      ? styles.activeRTL
                      : styles.active
                    : rtl
                    ? styles.itemRTL
                    : styles.item,
                ]}
                onPress={() => {
                  setMenu('VOrder');
                  setDrop(false);
                  props.navigation.navigate('VOrder');
                }}>
                <Icons
                  name="wallet-giftcard"
                  size={18}
                  color="#fff"
                  style={styles.itemIcon}
                />
                <Text style={styles.itemText}> {t('Order')} </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  menu === 'VProducts'
                    ? rtl
                      ? styles.activeRTL
                      : styles.active
                    : rtl
                    ? styles.itemRTL
                    : styles.item,
                ]}
                onPress={() => {
                  setMenu('VProducts');
                  setDrop(false);
                  props.navigation.navigate('VProducts');
                }}>
                <Icons
                  name="ballot"
                  size={18}
                  color="#fff"
                  style={styles.itemIcon}
                />
                <Text style={styles.itemText}> {t('Products')} </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  menu === 'VAddProducts'
                    ? rtl
                      ? styles.activeRTL
                      : styles.active
                    : rtl
                    ? styles.itemRTL
                    : styles.item,
                ]}
                onPress={() => {
                  setMenu('VAddProducts');
                  setDrop(false);
                  props.navigation.navigate('VAddProducts', {product: {}});
                }}>
                <Icons
                  name="plus-box-multiple"
                  size={18}
                  color="#fff"
                  style={styles.itemIcon}
                />
                <Text style={styles.itemText}> {t('Add Products')} </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  menu === 'VCustomers'
                    ? rtl
                      ? styles.activeRTL
                      : styles.active
                    : rtl
                    ? styles.itemRTL
                    : styles.item,
                ]}
                onPress={() => {
                  setMenu('VCustomers');
                  setDrop(false);
                  props.navigation.navigate('VCustomers');
                }}>
                <Icons
                  name="account-group"
                  size={18}
                  color="#fff"
                  style={styles.itemIcon}
                />
                <Text style={styles.itemText}> {t('Customers')} </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  menu === 'shop'
                    ? rtl
                      ? styles.activeRTL
                      : styles.active
                    : rtl
                    ? styles.itemRTL
                    : styles.item,
                ]}
                onPress={() => {
                  setMenu('shop');
                  setDrop(false);
                  props.navigation.navigate('VHome');
                }}>
                <Icons
                  name="basket"
                  size={18}
                  color="#fff"
                  style={styles.itemIcon}
                />
                <Text style={styles.itemText}> {t('Shop')} </Text>
              </TouchableOpacity>
            </View>
          </View>
        </DrawerContentScrollView>
      </View>
      <Modal
        animationType="fade"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(!modalVisible);
        }}>
        <TouchableOpacity
          style={styles.centeredView}
          onPress={() => {
            setModalVisible(!modalVisible);
          }}>
          <TouchableOpacity
            onPress={() => {
              setModalVisible(true);
            }}
            style={styles.modalView}>
            <TouchableOpacity
              style={{
                width: Window.width - 100,
                backgroundColor: '#fff',
                borderBottomWidth: 1,
                borderColor: '#fafafa',
                height: Window.height / 15,
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'flex-start',
                padding: 15,
              }}
              onPress={() => {
                rtlSet('enUS');
                setModalVisible(false);
              }}>
              <Text>En</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                width: Window.width - 100,
                backgroundColor: '#fff',
                borderBottomWidth: 1,
                borderColor: '#fafafa',
                height: Window.height / 15,
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'flex-start',
                padding: 15,
              }}
              onPress={() => {
                rtlSet('arUA');
                setModalVisible(false);
              }}>
              <Text>Ar</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                width: Window.width - 100,
                backgroundColor: '#fff',
                borderBottomWidth: 1,
                borderColor: '#fafafa',
                height: Window.height / 15,
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'flex-start',
                padding: 15,
              }}
              onPress={() => {
                rtlSet('heIL');
                setModalVisible(false);
              }}>
              <Text>He</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  topSection: {
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row',
    padding: 15,
  },
  topSectionRTL: {
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row-reverse',
    padding: 15,
  },
  logo: {
    width: 40,
    height: 30,
    marginRight: 10,
  },
  logoRTL: {
    width: 40,
    height: 30,
    marginLeft: 10,
  },
  header: {
    fontSize: 25,
    fontWeight: 'bold',
    color: '#fff',
  },
  body: {
    padding: 15,
  },
  userName: {
    fontSize: 18,
    color: '#fff',
  },
  logoutButn: {
    marginVertical: 10,
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row',
  },
  logoutButnRTL: {
    marginVertical: 10,
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
    flexDirection: 'row',
  },
  logoutButnIcon: {},
  menu: {
    display: 'flex',
    justifyContent: 'flex-start',
    alignContent: 'flex-start',
    paddingVertical: 50,
  },
  item: {
    display: 'flex',
    flexDirection: 'row',
    paddingVertical: 15,
    paddingHorizontal: 10,
    borderRadius: 5,
    marginVertical: 2,
  },
  itemRTL: {
    display: 'flex',
    flexDirection: 'row-reverse',
    paddingVertical: 15,
    paddingHorizontal: 10,
    borderRadius: 5,
    marginVertical: 2,
  },
  active: {
    display: 'flex',
    flexDirection: 'row',
    paddingVertical: 15,
    paddingHorizontal: 10,
    borderRadius: 5,
    marginVertical: 2,
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  activeRTL: {
    display: 'flex',
    flexDirection: 'row-reverse',
    paddingVertical: 15,
    paddingHorizontal: 10,
    borderRadius: 5,
    marginVertical: 2,
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  itemIcon: {
    marginHorizontal: 10,
  },
  itemText: {
    fontSize: 16,
    color: '#fff',
  },
  itemLeft: {
    flex: 1,
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row',
  },
  itemLeftRTL: {
    flex: 1,
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row-reverse',
  },
  dropWrapper: {
    paddingLeft: 15,
  },
  wrapper: {
    flex: 1,
    backgroundColor: 'rgba(34, 42, 69, 0.96)',
  },
  row: {
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row',
  },
  lang: {
    padding: 10,
    borderRadius: 30,
    backgroundColor: '#fff1',
    width: 100,
    marginHorizontal: 10,
    marginVertical: 15,
  },
  langActive: {
    padding: 10,
    borderRadius: 30,
    backgroundColor: '#00fa',
    width: 100,
    marginHorizontal: 10,
    marginVertical: 15,
  },
  langText: {
    color: '#fffe',
    textAlign: 'center',
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
  },
  modalView: {
    margin: 15,
    backgroundColor: 'white',
    borderRadius: 3,
    padding: 2,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  openButton: {
    backgroundColor: '#F194FF',
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
});

function mapStateToProps(state) {
  return {
    role: state.auth.role,
    userDetails: state.auth.userDetails,
    rtlVendor: state.theme.rtlVendor,
    langVendor: state.theme.langVendor,
  };
}

export default connect(mapStateToProps, {
  setRole,
  SetAuthLogout,
  setRTLVENDOR,
  setLangVendor,
})(CustomDrawerComponentVendor);
