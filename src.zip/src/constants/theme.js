export const RTL_VENDOR = 'RTL_VENDOR';
export const LANG_VENDOR = 'LANG_VENDOR';
export const RTL_CUSTOMER = 'RTL_CUSTOMER';
export const LANG_CUSTOMER = 'LANG_CUSTOMER';
export const RESET_THEME = 'RESET_THEME';