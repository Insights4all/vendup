import React from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  Image,
  CheckBox,
  TextInput,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import {connect} from 'react-redux';

import {setRole} from '../../actions/auth';

const Window = Dimensions.get('window');

const Singup = (props) => {
  const [terms, setTerms] = React.useState(false);

  const _handelSignUp = () => {
    props.setRole('admin');
    console.log('hi');
    // props.navigation.navigate('Home');
  };

  return (
    <>
      <View style={styles.body}>
        <View style={styles.topSection}>
          <Image source={require('../../assets/v2.png')} style={styles.logo} />
          <Text style={styles.header}>Vendup</Text>
        </View>
        <View style={styles.card}>
          <Image
            style={styles.img}
            source={require('../../assets/login-signup/posting_photo.png')}
          />
          <TextInput style={styles.input} placeholder="Name" />
          <TextInput style={styles.input} placeholder="Email" />
          <TextInput style={styles.input} placeholder="Password" />
          {/* <View style={styles.checkarea}>
            <CheckBox style={[styles.check, {marginTop: -5}]} />
            <Text style={styles.chechTxt}>
              I have read and agree to the terms of service.
            </Text>
          </View> */}
          <TouchableOpacity
            style={styles.checkarea}
            onPress={() => {
              setTerms(!terms);
            }}>
            <View
              style={{
                width: 20,
                height: 20,
                borderWidth: 1,
                borderRadius: 3,
                marginRight: 10,
              }}>
              {terms && <Feather name="check" size={18} color="#000" />}
            </View>
            <Text style={styles.chechTxt}>Remember Me</Text>
          </TouchableOpacity>
          <View style={styles.loginBtns}>
            <TouchableOpacity
              style={[styles.btn, styles.signin]}
              onPress={() => {
                _handelSignUp();
              }}>
              <Text style={{color: '#fff'}}>Sign Up</Text>
            </TouchableOpacity>
            <Text style={styles.or}>or</Text>
            <TouchableOpacity
              style={[styles.btn, styles.signup]}
              onPress={() => {
                props.navigation.navigate('Login');
              }}>
              <Text style={{color: '#000'}}>Sign In</Text>
            </TouchableOpacity>
          </View>
        </View>
        <View style={{marginTop: 20}}>
          <Text style={{textAlign: 'center', color: '#fffa'}}>
            {' '}
            Powered by Vendup{' '}
          </Text>
        </View>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  body: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: Window.width,
    height: Window.height,
    backgroundColor: '#1A2038',
  },
  card: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: Window.width - 30,
    padding: 25,
    backgroundColor: '#fff',
    borderRadius: 12,
  },
  img: {
    width: '100%',
    height: 160,
    marginBottom: 30,
  },
  input: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#999',
    borderRadius: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginBottom: 18,
  },
  checkarea: {
    display: 'flex',
    flexDirection: 'row',
    width: '100%',
    borderWidth: 1,
    borderColor: '#fff',
    marginBottom: 12,
  },
  loginBtns: {
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
  },
  or: {
    marginTop: 10,
    marginLeft: 18,
  },
  btn: {
    borderRadius: 7,
    paddingHorizontal: 18,
    paddingVertical: 8,
    height: 38,
  },
  signin: {
    backgroundColor: '#7467ef',
  },
  topSection: {
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    // flexDirection: 'row',
    padding: 15,
    marginTop: -50,
    marginBottom: 30,
  },
  logo: {
    width: 90,
    height: 70,
    marginBottom: 10,
  },
  header: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#fff',
  },
});

function mapStateToProps(state) {
  return {
    role: state.auth.role,
  };
}

export default connect(mapStateToProps, {setRole})(Singup);
// export default Singup;
