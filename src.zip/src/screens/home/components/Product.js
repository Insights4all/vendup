import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  Dimensions,
  TouchableOpacity,
  TouchableHighlight,
  TextInput,
  ToastAndroid
} from 'react-native';
// import FeatherIcons from 'react-native-vector-icons/Feather';
import HomeStyle from '../Home.style';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import { find } from 'lodash';

import { connect } from 'react-redux';
import { addProductToCart, updateCartAmount } from '../../../actions/cart';
import { getProductStatus } from '../../../utils/';

import { useNavigation } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';

const Window = Dimensions.get('window');
const Product = ({
  item,
  rtlCustomer,
  cartList,
  addProductToCart,
  updateCartAmount,
  userDetails
}) => {
  const { t } = useTranslation();
  const [discount, setDiscount] = React.useState(0);
  const [cartAmount, setCartAmount] = useState(null);
  const [quantity, setQuantity] = useState("0");

  const navigation = useNavigation();
  const rtl = rtlCustomer;
  const handleAddProduct = (item) => {
    let quantityTemp = quantity;
    if ((parseInt(quantity) === 0) || (quantity === "")) {
      quantityTemp = item.minOrderQuantity
    }
    if ((quantityTemp > item.quantity)) {
      ToastAndroid.showWithGravity(`${t('The maximum amount available is ')} ${item.quantity}`, ToastAndroid.SHORT, ToastAndroid.CENTER)
    }
    else if (item.minOrderQuantity > item.quantity) {
      ToastAndroid.showWithGravity(`${t('The maximum amount available is ')} ${item.quantity}`, ToastAndroid.SHORT, ToastAndroid.CENTER)
    }
    else if (quantityTemp < item.minOrderQuantity) {
      ToastAndroid.showWithGravity(`${t('The minimum order amount should be ')} ${item.minOrderQuantity}`, ToastAndroid.SHORT, ToastAndroid.CENTER)
    }
    else if (quantityTemp > item.maxOrderQuantity) {
      ToastAndroid.showWithGravity(`${t('The maximum order amount should be ')} ${item.maxOrderQuantity}`, ToastAndroid.SHORT, ToastAndroid.CENTER)
    }
    else {
      addProductToCart({ ...item }, parseInt(parseInt(quantityTemp)));
    }
  };

  const handleProductAmountChange = (action) => {
    if (action === 'add') updateCartAmount({ ...item, amount: cartAmount + 1 });
    else updateCartAmount({ ...item, amount: cartAmount - 1 });
  };

  useEffect(() => {
    let amount = find(cartList, { _id: item._id })?.amount * 1 || 0;
    setCartAmount(amount);
    setQuantity(String(amount))
  }, [cartList, item._id]);

  useEffect(() => {
    if (userDetails.percentDiscount)
      setDiscount(userDetails.percentDiscount)
  }, [userDetails])
  return (
    <TouchableHighlight
      // style={{margin: 10, backgroundColor: '#0000'}}
      style={{borderRadius:16, marginVertical:10,marginHorizontal:20, backgroundColor:"#fff"}}
      underlayColor={'#fff'}
      onPress={() => {
        navigation.navigate('ProductDetail', { product: item });
      }}>
      <View style={styles.card}>
        <View style={rtl ? styles.flexRowRTL : styles.flexRow}>
          <Image
            source={
              item.images[0]
                ? { uri: item.images[0] }
                : require('../../../assets/dummy-product.png')
            }
            style={styles.cardImage}
          />
          <View style={styles.cardBody}>
            <Text style={[styles.name, { textAlign: rtl ? 'right' : 'left' }]}>
              {item.productName}
            </Text>
            <View style={{ marginBottom: 5 }} />


            {/* AMOUNT MAIN */}

            <View style={{flexDirection:"row", justifyContent:"space-between", alignItems:"center"}}> 
            <Text
              style={[styles.mainPrice, { textAlign: rtl ? 'right' : 'left' }]}>
              $ {(item.specialPrice > 0 && item.isSpecial) ? String(item.specialPrice) : String((item.price - (item.price * discount) / 100).toFixed(2))}
            </Text>
            <View style={rtl ? styles.countRTL : styles.count}>
            <TouchableOpacity
              style={styles.countBtn}
              onPress={() => {
                cartAmount >= item.quantity ||
                  cartAmount >= item.maxOrderQuantity
                  ? console.log('Disabled')
                  : handleProductAmountChange('add');
              }}
              disabled={item?.children?.length > 0}
            >
              <FontAwesome5 name="plus" size={12} color="#ECA140" />
            </TouchableOpacity>
            <View style={styles.countText}>
              {/* <Text>{cartAmount}</Text> */}
              <TextInput
                // value={String(cartAmount)}
                // onChangeText={(value) =>
                //   updateCartAmount({...item, amount: value})
                // }
                style={{  color: "#000", textAlign: 'center', textAlignVertical: 'center', padding: 0, fontSize: 14 }}
                value={quantity}
                onChangeText={(value) => setQuantity(value)}
                keyboardType="number-pad"
                editable={!(item?.children?.length > 0)}
              />
            </View>
            <TouchableOpacity
              style={styles.countBtn}
              onPress={() =>
                cartAmount <= item.minOrderQuantity
                  ? console.log('Disabled')
                  : handleProductAmountChange('substract')
              }
              disabled={item?.children?.length > 0}
            >
              <FontAwesome5 name="minus" size={12} color="#ECA140" />
            </TouchableOpacity>
          </View>
            </View>
            <View style={{ marginBottom: 5 }} />
            {/* <Text style={[styles.price, { textAlign: rtl ? 'right' : 'left' }]}>
              {t('Original Price')}:
              <Text
                style={[
                  styles.strickeThrough,
                  { textAlign: rtl ? 'right' : 'left' },
                ]}>
                {' '}
                {String(item.price)}{' '}
              </Text>
            </Text> */}
            <View style={{ marginBottom: 5 }} />
            {getProductStatus(item.quantity).status === "Stock Out" && (
              <Text style={[styles.stock, { textAlign: rtl ? 'right' : 'left' }]}>
                {t('Stock')}:{' '}
                <Text style={[styles.gold, { textAlign: rtl ? 'right' : 'left' }]}>
                  {t(getProductStatus(item.quantity).status)}
                </Text>
              </Text>
            )}
          </View>
        </View>
        <View style={rtl ? styles.flexRowRTL : styles.flexRow}>



          <TouchableOpacity style={styles.removeButton}>
            <Text style={{textAlign:"center"}}>Remove</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={
              getProductStatus(item.quantity).status === 'Stock Out' ||
                cartAmount > 0
                ? styles.btnDisabled
                : styles.btnFill
            }
            onPress={() =>
              getProductStatus(item.quantity).status === 'Stock Out' ||
                cartAmount > 0
                ? console.log('Disabled')
                : item?.children?.length > 0 ? navigation.navigate('ProductDetail', { product: item }) : handleAddProduct(item)
            }>
            <Text style={styles.btnFillText}>
              <FontAwesome5
                name="shopping-cart"
                size={15}
                color="#fff"
                style={{ marginHorizontal: 10 }}
              />
              <Text> {t('Add to cart')} </Text>
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableHighlight>
  );
};
const styles = StyleSheet.create({
  ...HomeStyle,
});
function mapStateToProps(state) {
  return {
    vendors: state.shop.vendors,
    cartList: state.cart.cartList,
    rtlCustomer: state.theme.rtlCustomer,
    userDetails: state.auth.userDetails,
  };
}
export default connect(mapStateToProps, {
  addProductToCart,
  updateCartAmount,
})(Product);
