import {Colors, Fonts} from '../../theme';
import {Dimensions} from 'react-native';
const Window = Dimensions.get('window');
const HomeStyle = {
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  filterBtn: {
    // color: '#fff',
    backgroundColor: '#7467EF',
    borderColor: '#7467EF',
    borderWidth: 1,
    // marginHorizontal: 10,
    padding: 7,
    paddingHorizontal: 15,
    borderRadius: 3,
    elevation: 2,
    width: '48%',
    height: 40,
    marginTop: 15,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  specialBtn: {
    width: '48%',
    height: 40,
    display: 'flex',
    justifyContent: 'center',
    // borderWidth: 1,
    borderRadius: 3,
    padding: 7,
    paddingHorizontal: 15,
    display: 'flex',
    alignItems: 'center',
    backgroundColor: '#d0b422',
    elevation: 2,
    flexDirection: 'row',
    marginTop: 15,
  },
  card: {
    // width: Window.width - 40,
    // elevation: 2,
    // backgroundColor: '#fff',
    padding: 15,
    borderRadius: 3,
    borderColor: '#eee',
    borderBottomWidth: 1,
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    flexDirection: 'column',
  },
  flexRow: {
    display: 'flex',
    flexDirection: 'row',
    flex: 1,
    width: '100%'
  },
  flexRowRTL: {
    display: 'flex',
    flexDirection: 'row-reverse',
    flex: 1,
    // backgroundColor: '#000',
    width: '100%'
  },
  cardImage: {
    width: 80,
    height: 80,
    marginTop: 5,
    marginHorizontal: 10
  },
  cardBody: {
    marginLeft: 15,
  },
  name: {
    fontWeight: 'bold',
    fontSize: 16,
    letterSpacing: 1,
    lineHeight: 25,
    width: Window.width - 130,
    // backgroundColor: '#000'
  },
  strickeThrough: {
    textDecorationLine: 'line-through',
    color: '#777',
  },
  price: {
    color: '#777',
    fontSize: 12,
  },
  stock: {
    color: '#777',
    fontSize: 12,
  },
  btnFill: {
    backgroundColor:"#ECA140",
    // padding: 10,
    borderRadius: 5,
    // elevation: 10,
    marginTop: 10,
    width: 'auto',
    flex: 1,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 30,
    height: 35
  },
  btnDisabled: {
    backgroundColor: '#ccc',
    // padding: 10,
    borderRadius: 3,
    // elevation: 10,
    marginTop: 10,
    width: 'auto',
    flex: 1,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 30,
    height: 35
  },
  removeButton:{
    borderWidth:1,
    backgroundColor: '#fff',
    borderColor:"#D4D5D9",
    borderRadius: 3,
    marginTop: 10,
    width: 'auto',
    flex: 1,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: 35

    
  },
  btnFillText: {
    color: '#fff',
    fontSize: 14,
    marginHorizontal: 10,
  },
 
  mainPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    color: "#ECA140"
  },
  row: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  count: {
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row',
    marginVertical: 10,
    marginLeft: 15,
    right:35
    
  },
  countRTL: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row-reverse',
    marginVertical: 10,
    marginRight: 15,
    flex: 1,

  },
  countBtn: {
    padding: 7,
    backgroundColor: '#fff',
    borderRadius: 3,
    borderWidth:1,
    borderColor:"#E8E8EA",
    right:22,

  },
  countText: {
    width: 30,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fafafa',
    height: 30,
    marginTop: 5,
    right:22,
    bottom:2
  },
  headerWrapper: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    // width: '100%',
    paddingLeft: 0,
    backgroundColor:"#F5F5F6",
    paddingBottom: 5,
    paddingLeft: 20,
    paddingRight: 20,
    flexDirection: 'row',
  },
  
  
};

export default HomeStyle;
