import React, {useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Dimensions,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  TextInput,
  Pressable,
} from 'react-native';
import FeatherIcon from 'react-native-vector-icons/Feather';
import HomeStyle from './Home.style';
import {Colors} from '../../theme';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';

// component
import Body from '../../components/template/body/Body';
import Header from '../../components/template/header/Header';
import Filter from '../../components/home/filter/Filter';
import Product from './components/Product';

import {connect} from 'react-redux';
import {fetchShop} from '../../actions/shop';
import {addProductToCart, updateCartAmount} from '../../actions/cart';
import {searchProduct, setFilters, filterProduct} from '../../actions/shop';
import Icons from 'react-native-vector-icons/MaterialIcons';
import {useNavigation} from '@react-navigation/native';
import {useTranslation} from 'react-i18next';
import {paginator} from '../../utils/';

const Window = Dimensions.get('window');

const Home = (props) => {
  const {t} = useTranslation();
  const rtl = props.rtlCustomer;
  const [sideNav, setSideNav] = React.useState(false);
  const [products, setProducts] = React.useState([]);
  const [loadMoreLoading, setLoadMoreLoading] = React.useState(false);
  const [searchText, setSearchText] = React.useState('');
  const [pagination, setPagination] = React.useState({
    limit: 25,
    offset: 25,
  });

  const navigation = useNavigation();

  const loadData = () => {
    if (
      typeof props.activeVendorId !== 'undefined' &&
      props.vendors.length > 0
    ) {
      props.fetchShop(props.vendors[props.activeVendorId]._id);
      console.log(props.vendors);
    }
  };
  useEffect(() => {
    if (props.vendors.length) {
      loadData();
    }
  }, [props.vendors]);
  useEffect(() => {
    if (props.products.length) {
      setProducts([...props.products.slice(0, 25)]);
      setLoadMoreLoading(false);
    } else {
      setProducts([]);
      setLoadMoreLoading(false);
    }
  }, [props.products]);
  const handleLoadMore = async () => {
    return new Promise((resolve, reject) => {
      setProducts([
        ...products,
        ...paginator(props.products, pagination.offset, pagination.limit).data,
      ]);
      setPagination({
        ...pagination,
        offset: pagination.limit + pagination.offset,
      });
      resolve();
    });
  };
  const handleSpecialFilter = () => {
    props.setFilters({
      ...props.filters,
      isSpecial: !props.filters.isSpecial,
    });
    props.filterProduct({
      ...props.filters,
      isSpecial: !props.filters.isSpecial,
    });
  };
  useEffect(() => {
    if (props.vendors.length > 0) loadData();
  }, [props.activeVendorId]);
  const renderItem = ({item}) => (
    <View style={{backgroundColor: '#F5F5F6'}}>
      <Product item={item} />
    </View>
  );
  let onEndReachedCalledDuringMomentum = false;
  if (props.loading)
    return (
      <ActivityIndicator size="large" color="#000" style={{marginTop: 20}} />
    );
  else
    return (
      <View backgroundColor="F6F6F7" style={{backgroundColor: '#F6F6F7'}}>
        {sideNav && (
          <Filter
            onClose={() => {
              setSideNav(!sideNav);
            }}
            scope="customer"
          />
        )}
        <Header
          title="Home"
          lang={true}
          cart={true}
          right={true}
          onSearchChange={(value) => props.searchProduct(value)}
        />
        {/* <View style={{flexDirection:"row"}}> */}

        <View
          style={[
            rtl ? styles.searchRTL : styles.search,
            {
              backgroundColor: 'lightgrey',
              marginHorizontal: 20,
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              borderRadius: 8,
              paddingHorizontal: 10,
              height: 55,
              bottom: 20,
              zIndex: 1000000,
              elevation: 1000,
            },
            // {width: props.cart === false ? '90%' : '75%'},
          ]}>
          <FontAwesome5 name="search" size={15} color="#777" />
          <TextInput
            placeholder={t('Search here')}
            style={[styles.searchInput, {flex: 1}]}
            onChangeText={(value) => {
              props.searchProduct(value);
              setSearchText(value);
              console.log(value);
            }}
            value={searchText}
          />
          <Pressable
            style={{width: 20}}
            onPress={() => {
              setSearchText('');
              props.onSearchChange('');
            }}>
            <FeatherIcon
              name="x"
              size={15}
              // color={searchText !== '' ? '#222' : '#fff'}
              color={searchText !== '' ? '#000' : '#000'}
            />
          </Pressable>
        </View>
        {/* </View> */}

        <FlatList
          style={{height: Window.height - 170, marginTop: 0}}
          data={products}
          renderItem={renderItem}
          keyExtractor={(item, i) => i}
          onEndReachedThreshold={0.1}
          onEndReached={() => (onEndReachedCalledDuringMomentum = true)}
          onMomentumScrollEnd={async () => {
            if (onEndReachedCalledDuringMomentum) {
              console.log('Hello=>', products.length);
              setLoadMoreLoading(true);
              onEndReachedCalledDuringMomentum = false;
              await handleLoadMore();
              setLoadMoreLoading(false);
            }
          }}
          refreshControl={
            <RefreshControl refreshing={props.loading} onRefresh={loadData} />
          }
          ListHeaderComponent={() => (
            <>
              <View style={styles.headerWrapper}>
                <TouchableOpacity
                  style={[
                    styles.specialBtn,
                    {
                      backgroundColor: '#ECA140',
                      width: 'auto',
                      borderRadius: 6,
                    },
                  ]}
                  onPress={() => {
                    handleSpecialFilter();
                  }}>
                  <Text
                    style={[styles.btnText, {color: '#ffff', marginLeft: 5}]}>
                    {props.filters.isSpecial
                      ? t('All Products')
                      : t('Favourites')}
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styles.specialBtn,
                    {
                      backgroundColor: '#fff',
                      borderWidth: 1,
                      elevation: 0,
                      borderColor: '#D4D5D9',
                      borderRadius: 6,
                      width: 'auto',
                    },
                  ]}
                  onPress={() => {
                    handleSpecialFilter();
                  }}>
                  <Text
                    style={[styles.btnText, {color: '#000', marginLeft: 5}]}>
                    Saved Lists
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styles.specialBtn,
                    {
                      backgroundColor: '#FF4A76',
                      // borderWidth:1,
                      elevation: 0,
                      // borderColor:"#D4D5D9",
                      borderRadius: 6,
                      width: 'auto',
                    },
                  ]}
                  onPress={() => {
                    handleSpecialFilter();
                  }}>
                  <Text
                    style={[styles.btnText, {color: '#fff', marginLeft: 5}]}>
                    Specials
                  </Text>
                </TouchableOpacity>
              </View>
            </>
          )}
          ListFooterComponent={() =>
            loadMoreLoading && (
              <ActivityIndicator
                color="#000"
                style={{marginBottom: 20}}
                size="large"
              />
            )
          }
        />
      </View>
    );
};

const styles = StyleSheet.create({
  ...HomeStyle,
});
function mapStateToProps(state) {
  return {
    products: state.shop.products,
    loading: state.shop.loading,
    vendors: state.shop.vendors,
    cartList: state.cart.cartList,
    rtlCustomer: state.theme.rtlCustomer,
    activeVendorId: state.shop.activeVendorId,
    filters: state.shop.filters,
  };
}
export default connect(mapStateToProps, {
  fetchShop,
  addProductToCart,
  updateCartAmount,
  searchProduct,
  setFilters,
  filterProduct,
})(Home);
