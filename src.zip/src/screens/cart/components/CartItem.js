import React, {useState, useEffect, useCallback} from 'react';
import {
  StyleSheet,
  View,
  Text,
  Dimensions,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  Image,
  Button,
} from 'react-native';

import {connect} from 'react-redux';
import {deleteProductFromCart, updateCartAmount} from '../../../actions/cart';
import Icon from 'react-native-vector-icons/Feather';
import {useTranslation} from 'react-i18next';

const Window = Dimensions.get('window');
// components
import {debounce} from 'lodash';

const CartItem = (props) => {
  const {t} = useTranslation();
  const rtl = props.rtlCustomer;
  const [amount, setAmount] = useState(String(props.item.amount));
  const [discount, setDiscount] = React.useState(0);

  const handleProductAmountChange = (action) => {
    if (action === 'add') {
      props.updateCartAmount({...props.item, amount: props.item.amount + 1});
      setAmount(String(props.item.amount + 1));
    } else {
      props.updateCartAmount({...props.item, amount: props.item.amount - 1});
      setAmount(String(props.item.amount - 1));
    }
  };
  const handleUpdateCartAmount = useCallback(
    debounce((amount) => {
      if (amount > props.item.quantity) {
        ToastAndroid.showWithGravity(
          `${t('The maximum amount available is ')} ${props.item.quantity}`,
          ToastAndroid.SHORT,
          ToastAndroid.CENTER,
        );
        setAmount(String(props.item.amount));
      } else {
        props.updateCartAmount({
          ...props.item,
          amount: amount ? parseInt(amount) : 1,
        });
      }
    }, 1000),
  );
  useEffect(() => {
    handleUpdateCartAmount(amount);
  }, [amount]);

  useEffect(() => {
    if (props.userDetails.percentDiscount)
      setDiscount(props.userDetails.percentDiscount);
  }, [props.userDetails]);

  return (
    <View
      style={[
        rtl ? styles.flexRowRTL : styles.flexRow,
        styles.cartcard,
        {
          backgroundColor: '#fff',
          paddingRight: rtl ? 0 : 15,
          width: rtl ? '98%' : '101%',
          borderRadius: 5,
          // elevation: 3,
          padding: 10,
        },
      ]}>
      <View>
        <Image
          style={{width: 80, height: 90}}
          source={{
            uri:
              'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8SEhAQEg8VDxAVFQ8VEA8VFQ8PDxUVFRUWFhUVFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMvNygtLisBCgoKDg0NFQ0PFSsZFRkrKy0tLS0tNy0rLTcrKy0rLS0tLTcrLTgtKy0rKysrKy0tKy0rNy0rKy0rKysuKys3K//AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEBAAIDAQEAAAAAAAAAAAAAAQIHAwYIBQT/xABMEAACAQMABAgHCwoEBwAAAAAAAQIDBBEFBxIhBhMxQVFhcZEUIiMygaHBFyRUcnSCk7Gy0dIlQkNSYmNzg7PTRFOSowgVMzQ1w/D/xAAWAQEBAQAAAAAAAAAAAAAAAAAAAQL/xAAZEQEBAQADAAAAAAAAAAAAAAAAEQEhMUH/2gAMAwEAAhEDEQA/AN4gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACNpb3uXO+Y6pp7WLou1zGVwq9RZ8lR8tLPQ5LxYvtYHa2z89hpChXjt0a1OvDLTlTnCpHK3NZi+U8+cNNYt5eucIydvavcqEXhyX72a3yz0blzYeMvqOiL+vQm6lGtOjPPnQk4S5eR45V1MsHroGgNG629K0klPibhLldSm41H86nKK9TPs0td1VY29HQa52q8oep02INzA0/W127vE0dv6ZV/Yqe86vp3WnpW4TjCcbWD5qKanjrqSbeeuOyIPQcLmm5ypqpF1IqLnTUoucVLzXKPKk8M5TyRo7StxQreEUq06ddSb41Sbm28Z2m/OT508p85unghrbt6sY0773vW5HWjF+Dy63htwfTnd18wg2cDhtLulViqlKpGrB+bOEozg+xrccxAAAAAAAAAAAAAAAAAAAAHxeEnCmzsYqVxV2ZPzKUVt1ZdkVzdbwus1Vwi1v3VVuNnTVrBfpJqFWvL0PMIrq8btEGzeEfDXR9kpKrXU6qz73ptVKzfQ4p+L85o1lpjXLdzyre3p28d+JTbr1Op80U+rDNa3Nec5SnOW1OUpSnLncpNuT9LbOM1B9XTHCS9us+EXVSsn+Y5bNL6OOI+o+VgmRkIk0Ypcvq5jkMGBVnpO/cH9W6urO3u5X6tpVeN8jKi6udio4LZanF8iTe58pr/AGjafBbWRo6ja2tpXta0nSi4uqo0akMtuUmvHUlv6mXJeek2zjt0jhvwcno65Vq6sa7dKnV24xdNePKcdnDb/UznPOdfafO/Qdp1jafo315x1CLjRjSo0obUVTb2dpvxeZZnj0HWVuIqRXMcikYoZA/ZYaTr0JbdCtUoT55U5ypt9uHv9J3HRGtvSlHCqOF3HnVSKhUx1ThjvaZ0LIyBu/Ruuq1kkri0q0ZP/LlTuId72H6mdr4L8O7C/qTo0JyjVitpQqRUHOPPKG95Sb3rl6jzMukwoVpxkpxlKE08xnFuE0+mMlvT7CRXsMHn7g7rZ0hb4jWxfUv2/ErLsqJb/nJvrNocHtZei7rC47waq/0VfFPf1TzsS789Qg7iCRkmk08p8jW9MpAAAAAAAfK09wis7KKlcV40852YedUlj9WC3vt5N5qvhNrdr1NqnZU+IjycdNKdZ9aj5sfX6CwbW05wgtLOO3cV40uiOc1JfFgt79CNU8KdbdepmnZQ8Hhv8tNRlWfxY74w9b7DW91dVKkpVKlSVSpJ5lUk3KTfW2cDZYOS6up1JSnUnKpUk8ynJuc2+tvez8+0VojAxbyC4EgiEBArLJizIwYRHESbKTAESMkTBkkAwGXBGBMFIg2BJ8hijKXIYhVGSAD7egeFN9ZteD3M6Uf8vO3RfbTlmPpxk2ToDXRyRvLb+dQ9tOb+qXoNOJmSIPVGgeFVheL3vcwqS56TzTrLtpyxLG578YPsnkGEmmmnhremtzT6U+Y3LqY09pK5qVqdau61rSpxzKotqqpyeIRjU5WsRm3nPIuTIg2yACDz7rU0NUt76pOUpTp181KU5NyeM+NTy/1W9y5k4nS2eitZnB/wyymoRzWo+Vo9LcU9qHpjn0qJ5zlNf/chrwGzBlbJkCMJBsmQKYSZckkBEwYw3mWABC5IEACZApkjAZA5CMxTG0BSMrZGBjL7iFkQKABAEVAAZo9IaqtBeCaPpbUcVa3l6udzTmlsRfZBRWOnJorgRoTwy+trZrapualWW7HFQ8aafU0tn5yPUpNAAEA856z+Dngd7PZjihW2qtHoWX5SC+LJ8nRKJ6MOp6zODnhtlNRjmvSzVodLcV40PnRyu3ZfMXB5wQwZMxZURmEmZYMWgpE/PWq53I5a89lY5z81Hl5MkH6oLcMk3gqKQpAoQpAAAAAAIDJAwq55jGJhKfIZSeGmBmGgmACKgolw+3qA3NqF0JiFxfyW+b4mi/2Y4lUkupy2V/LZts+RwR0SrSztbbGHCnHb65vxqj9MnJn1zIAAAAAPOGsrQHgd9WjFYo1fLUejZm3tR9E9pY6NnpOr0aTm9mEZVJ/qQTlLuW89Q6a4NWV5KlO5oRruntqmpOWytrZzmKeJeauXJ+6ysaNGKp0aUKMFyQhGMI9yLR5oo8DNK1EpR0dX2eZShKk+6eGZx1f6ab/8dUxz+NQX1zPTh03W7pV2+i7lxlszqcXRg03GXlJJTw1z8Wpv0CjzNcy3tdDfeclBHDGB+mnHAGWQisxKigJAAARsKAAAQBAUFRiBxTR9jg9wbu77jIWtJVp00nOHGUacsPOGlOSysrHcfLksn3dX2lpWmkbOsm1F1I0qvQ6dVqEs9SypfNRB2G21Q6Ykt8KFP49b8EZH17XUneP/AKl5Rp/FhVq/Xsm8AKNJXGpS6XmXtGfVKnUp/U5HDoDVXpCneWzrwpu3hVhOpUhUjJOMHtqOy0pPacVF7uSTN5gUAAQAAAAAAAADV2v2LdrZrm8Iba5t1Kok/W+82iat19z972a6a033Qa9pcGkNhEMzFlRAhkBQZIAKYsqIBQABBgAAUiKASMZtpNp4kt6fOmjIxqPc+x/UB7CoT2oxl0qL70ZnDZyTp02uRxg12NI5jIAAAAAAAAAAAAABqTX/AD8WwXTK5fcqS9pts05/xAPx7Bfs3X10i4NRZMWVmLKgAQC5BEZZCoQNjIFIAAAAAZIGBSVOR9gMkwPW2hWvB7fHJxVHHZsI/afL4Lr3lZfJ7b+nE+oZAAAAAAAAAAAAAANM/wDEA/K2HxLr7VI3MaU1/vy9kuilX9c4fcXBqhkDIUAQAZJFAyERogyQKuQRFAApAiAAKFIZID1ZwQqbVjYy6ba2/pxPrnXNXM86L0d8noruil7DsZkAAAAAAAAAAAAAA0hr7l76tV0UJPvqP7jd5o3X3/3lt8n/APZP7i4NXsxMmYFAAgGSYIQCsELgACMMDLJCACggAqM4nFkzgwPUOrmONGaP+T0n3rPtOxnXNXMs6L0f8npLuWPYdjMgAAAAAAAAAAAAAGhte9b3/Sj0W1PHpqVfuN8mgNe+P+Yw6rWj/UrFwa6ciEBQBABRkgApTEqYAhcgAQpAAAAhlAgiB6e1Xv8AJVj/AA39uR2k6rqtf5Ksf4cvVUmdqMgAAAAAAAAAAAAAHnrXi86UfVbW/wBqq/aehTzxrsl+VKnVRt16pP2lwdBZiUFEQKxgCADAEBUhgAUEApCgCAAARlIB6R1M1trRNt0xlcx7q9THqaO7nQNR7/JdP+LcfbO/mQAAAAAAAAAAAAADznrjlnStx1Qt1/txftPRh1nTPAPRl1WncV6DqVZbKlLjK8E9lKK8WMkuRIuDzE0TB6T9y/QvwP8A3bn8ZVqx0L8CX0tx+MUea0g0elfcx0L8CX0tx+M4Xqq0LnPgsuzj7rHdtijzfgYPR8tVGhH/AISX091+M4amqHQr5KFWHWq9w/tSYo87pDB6D9x3RHRX+mf3E9xzRH7/AOlf3Cjz7gmD0BLU1ormncr+bH2wOCWpTRr/AMRdL59D20xRobAwb3epLR3wq7Xzrb+0T3EdH/C7v/Va/wBkUaIaBvZ6kdH/AAu7/wBVr/aPyXeo6j+i0hUg/wB5Sp1vsOAo0pgYNt1dR1f83SNOXbQnD6qjPnXGpbSa8ytazXXOtB93FtesDt+oGu3YV4P8y6qJdkqdKX1uRs06Rqo4LXOj7e4pXChxk67mtiW3HY4qnFb8LfmMju5AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/9k=',
          }}
          resizeMode={'cover'}
        />
      </View>

      <View
        style={[
          rtl ? styles.flexRowRTL : styles.flexRow,
          {marginLeft: rtl ? -10 : 0, backgroundColor: '#0000'},
        ]}>
        <View>
          <Image
            source={{
              uri:
                'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8SEhAQEg8VDxAVFQ8VEA8VFQ8PDxUVFRUWFhUVFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMvNygtLisBCgoKDg0NFQ0PFSsZFRkrKy0tLS0tNy0rLTcrKy0rLS0tLTcrLTgtKy0rKysrKy0tKy0rNy0rKy0rKysuKys3K//AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEBAAIDAQEAAAAAAAAAAAAAAQIHAwYIBQT/xABMEAACAQMABAgHCwoEBwAAAAAAAQIDBBEFBxIhBhMxQVFhcZEUIiMygaHBFyRUcnSCk7Gy0dIlQkNSYmNzg7PTRFOSowgVMzQ1w/D/xAAWAQEBAQAAAAAAAAAAAAAAAAAAAQL/xAAZEQEBAQADAAAAAAAAAAAAAAAAEQEhMUH/2gAMAwEAAhEDEQA/AN4gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACNpb3uXO+Y6pp7WLou1zGVwq9RZ8lR8tLPQ5LxYvtYHa2z89hpChXjt0a1OvDLTlTnCpHK3NZi+U8+cNNYt5eucIydvavcqEXhyX72a3yz0blzYeMvqOiL+vQm6lGtOjPPnQk4S5eR45V1MsHroGgNG629K0klPibhLldSm41H86nKK9TPs0td1VY29HQa52q8oep02INzA0/W127vE0dv6ZV/Yqe86vp3WnpW4TjCcbWD5qKanjrqSbeeuOyIPQcLmm5ypqpF1IqLnTUoucVLzXKPKk8M5TyRo7StxQreEUq06ddSb41Sbm28Z2m/OT508p85unghrbt6sY0773vW5HWjF+Dy63htwfTnd18wg2cDhtLulViqlKpGrB+bOEozg+xrccxAAAAAAAAAAAAAAAAAAAAHxeEnCmzsYqVxV2ZPzKUVt1ZdkVzdbwus1Vwi1v3VVuNnTVrBfpJqFWvL0PMIrq8btEGzeEfDXR9kpKrXU6qz73ptVKzfQ4p+L85o1lpjXLdzyre3p28d+JTbr1Op80U+rDNa3Nec5SnOW1OUpSnLncpNuT9LbOM1B9XTHCS9us+EXVSsn+Y5bNL6OOI+o+VgmRkIk0Ypcvq5jkMGBVnpO/cH9W6urO3u5X6tpVeN8jKi6udio4LZanF8iTe58pr/AGjafBbWRo6ja2tpXta0nSi4uqo0akMtuUmvHUlv6mXJeek2zjt0jhvwcno65Vq6sa7dKnV24xdNePKcdnDb/UznPOdfafO/Qdp1jafo315x1CLjRjSo0obUVTb2dpvxeZZnj0HWVuIqRXMcikYoZA/ZYaTr0JbdCtUoT55U5ypt9uHv9J3HRGtvSlHCqOF3HnVSKhUx1ThjvaZ0LIyBu/Ruuq1kkri0q0ZP/LlTuId72H6mdr4L8O7C/qTo0JyjVitpQqRUHOPPKG95Sb3rl6jzMukwoVpxkpxlKE08xnFuE0+mMlvT7CRXsMHn7g7rZ0hb4jWxfUv2/ErLsqJb/nJvrNocHtZei7rC47waq/0VfFPf1TzsS789Qg7iCRkmk08p8jW9MpAAAAAAAfK09wis7KKlcV40852YedUlj9WC3vt5N5qvhNrdr1NqnZU+IjycdNKdZ9aj5sfX6CwbW05wgtLOO3cV40uiOc1JfFgt79CNU8KdbdepmnZQ8Hhv8tNRlWfxY74w9b7DW91dVKkpVKlSVSpJ5lUk3KTfW2cDZYOS6up1JSnUnKpUk8ynJuc2+tvez8+0VojAxbyC4EgiEBArLJizIwYRHESbKTAESMkTBkkAwGXBGBMFIg2BJ8hijKXIYhVGSAD7egeFN9ZteD3M6Uf8vO3RfbTlmPpxk2ToDXRyRvLb+dQ9tOb+qXoNOJmSIPVGgeFVheL3vcwqS56TzTrLtpyxLG578YPsnkGEmmmnhremtzT6U+Y3LqY09pK5qVqdau61rSpxzKotqqpyeIRjU5WsRm3nPIuTIg2yACDz7rU0NUt76pOUpTp181KU5NyeM+NTy/1W9y5k4nS2eitZnB/wyymoRzWo+Vo9LcU9qHpjn0qJ5zlNf/chrwGzBlbJkCMJBsmQKYSZckkBEwYw3mWABC5IEACZApkjAZA5CMxTG0BSMrZGBjL7iFkQKABAEVAAZo9IaqtBeCaPpbUcVa3l6udzTmlsRfZBRWOnJorgRoTwy+trZrapualWW7HFQ8aafU0tn5yPUpNAAEA856z+Dngd7PZjihW2qtHoWX5SC+LJ8nRKJ6MOp6zODnhtlNRjmvSzVodLcV40PnRyu3ZfMXB5wQwZMxZURmEmZYMWgpE/PWq53I5a89lY5z81Hl5MkH6oLcMk3gqKQpAoQpAAAAAAIDJAwq55jGJhKfIZSeGmBmGgmACKgolw+3qA3NqF0JiFxfyW+b4mi/2Y4lUkupy2V/LZts+RwR0SrSztbbGHCnHb65vxqj9MnJn1zIAAAAAPOGsrQHgd9WjFYo1fLUejZm3tR9E9pY6NnpOr0aTm9mEZVJ/qQTlLuW89Q6a4NWV5KlO5oRruntqmpOWytrZzmKeJeauXJ+6ysaNGKp0aUKMFyQhGMI9yLR5oo8DNK1EpR0dX2eZShKk+6eGZx1f6ab/8dUxz+NQX1zPTh03W7pV2+i7lxlszqcXRg03GXlJJTw1z8Wpv0CjzNcy3tdDfeclBHDGB+mnHAGWQisxKigJAAARsKAAAQBAUFRiBxTR9jg9wbu77jIWtJVp00nOHGUacsPOGlOSysrHcfLksn3dX2lpWmkbOsm1F1I0qvQ6dVqEs9SypfNRB2G21Q6Ykt8KFP49b8EZH17XUneP/AKl5Rp/FhVq/Xsm8AKNJXGpS6XmXtGfVKnUp/U5HDoDVXpCneWzrwpu3hVhOpUhUjJOMHtqOy0pPacVF7uSTN5gUAAQAAAAAAAADV2v2LdrZrm8Iba5t1Kok/W+82iat19z972a6a033Qa9pcGkNhEMzFlRAhkBQZIAKYsqIBQABBgAAUiKASMZtpNp4kt6fOmjIxqPc+x/UB7CoT2oxl0qL70ZnDZyTp02uRxg12NI5jIAAAAAAAAAAAAABqTX/AD8WwXTK5fcqS9pts05/xAPx7Bfs3X10i4NRZMWVmLKgAQC5BEZZCoQNjIFIAAAAAZIGBSVOR9gMkwPW2hWvB7fHJxVHHZsI/afL4Lr3lZfJ7b+nE+oZAAAAAAAAAAAAAANM/wDEA/K2HxLr7VI3MaU1/vy9kuilX9c4fcXBqhkDIUAQAZJFAyERogyQKuQRFAApAiAAKFIZID1ZwQqbVjYy6ba2/pxPrnXNXM86L0d8noruil7DsZkAAAAAAAAAAAAAA0hr7l76tV0UJPvqP7jd5o3X3/3lt8n/APZP7i4NXsxMmYFAAgGSYIQCsELgACMMDLJCACggAqM4nFkzgwPUOrmONGaP+T0n3rPtOxnXNXMs6L0f8npLuWPYdjMgAAAAAAAAAAAAAGhte9b3/Sj0W1PHpqVfuN8mgNe+P+Yw6rWj/UrFwa6ciEBQBABRkgApTEqYAhcgAQpAAAAhlAgiB6e1Xv8AJVj/AA39uR2k6rqtf5Ksf4cvVUmdqMgAAAAAAAAAAAAAHnrXi86UfVbW/wBqq/aehTzxrsl+VKnVRt16pP2lwdBZiUFEQKxgCADAEBUhgAUEApCgCAAARlIB6R1M1trRNt0xlcx7q9THqaO7nQNR7/JdP+LcfbO/mQAAAAAAAAAAAAADznrjlnStx1Qt1/txftPRh1nTPAPRl1WncV6DqVZbKlLjK8E9lKK8WMkuRIuDzE0TB6T9y/QvwP8A3bn8ZVqx0L8CX0tx+MUea0g0elfcx0L8CX0tx+M4Xqq0LnPgsuzj7rHdtijzfgYPR8tVGhH/AISX091+M4amqHQr5KFWHWq9w/tSYo87pDB6D9x3RHRX+mf3E9xzRH7/AOlf3Cjz7gmD0BLU1ormncr+bH2wOCWpTRr/AMRdL59D20xRobAwb3epLR3wq7Xzrb+0T3EdH/C7v/Va/wBkUaIaBvZ6kdH/AAu7/wBVr/aPyXeo6j+i0hUg/wB5Sp1vsOAo0pgYNt1dR1f83SNOXbQnD6qjPnXGpbSa8ytazXXOtB93FtesDt+oGu3YV4P8y6qJdkqdKX1uRs06Rqo4LXOj7e4pXChxk67mtiW3HY4qnFb8LfmMju5AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/9k=',
            }}
          />
        </View>

        <TouchableOpacity
          style={[
            rtl ? styles.flexRowRTL : styles.flexRow,
            {width: rtl ? '95%' : 'auto'},
          ]}>
          {/* <View style={{marginHorizontal: 10}}>
                    <Image
                      style={{width: 80, height: 80}}
                      source={
                        props.item.images[0]
                          ? {uri: props.item.images[0]}
                          : require('../../assets/dummy-product.png')
                      }
                    />
                  </View> */}
          <View
            style={{
              marginLeft: 15,
              marginTop: 10,
              width: '85%',
            }}>
            <View style={{flex: 1, flexDirection: 'row', justifyContent:"space-between"}}>
              <Text
                style={{
                  fontSize: 18,
                  fontFamily: 'Roboto',
                  padding: 5,

                  textAlign: rtl ? 'right' : 'left',
                }}>
                {props.item.productName}
              </Text>
              <TouchableOpacity
                style={{
                  // marginLeft: 80,
                  // marginRight: 10,
                  marginTop: 0,
                  right:35
                }}
                onPress={() => props.deleteProductFromCart(props.item)}>
                <Image
                  style={{width: 22, height: 22}}
                  source={{
                    uri:
                      'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAkFBMVEX/////pQD/owD/ogD/oAD/v1r/0qD/qAD//fb/3af/6cX/siv/9+b/v1X/1JL/sS7/3q3/5b//8NX/t0L/7Mv/u0z/4rP/w2X/tTv/+/L/4rf/2qH/89z/1Zv/0ZX/rRv/ynj/zIT/xm3/t0f/zH7/rBX/4Kz/2qD/wV//0Yj/sTf/ynr/sz7/rxX/57//0ZZv6CjYAAAF+ElEQVR4nO2d7VriOhRGbRKmBatAAQXEoS2ooCPn/u/uFPAcmewCTZo0Ad/10yeNe5E0zUeb3NxYJIqT/rS35dcR2u3etDOb2AzCHtE0n3Mhwb85+Gs4epu5DleZOLvlnAXVYEyErb7rkJWIl0xU1ftf8n3qOuzq3AeKfntJMUhcR16NZKDjty/I+8h19BVoh5p+u2JcxK7jP0uuW4B7eOh5TZ3ciTp+22IMvG5wohGvKei7YqtuCe4UWce1x1EeTQgWiqGvPZy2GcGiufnj50MjCWq1ooeIpWuZMqKBMcGiovp4KxqrozvDW//qaVSjK1OCaLsWIhwpwmLMsBsWsr/5HiEeGWKxF+8K8bYs0mLcd7d+7QyTZBbvme1Jdgw7m6flmJU6ijfXRhKbss4Mnz9V6EgPR2XlyMaeFeKqxFCkFSdgXsueM2xoN2JFJi80RnFf+fJhiaLILMarTp+2M2KtcH1CW2LWtRatDjmppGyglEFJU8y96p12aREo3kZ3JAfRsxOrFjG5j1hLMYsOMeS5lVj1GNLwlIexY/Ij3doIVRNyF7EX5Zn6e5qHjVA1odGNlPMYkjxCj+bdlnJTKn6rZ0JaU+aRIXlYCI3ZJPJI9OlxQfpsQmOd5VM2FF4baozRyegEhkaJTnLTIsFNT19Rlgkx5Mm5S0wQv6Wru8VgPB53T/AixRaw+ank5ch5FI/8E6mLiAaDUStf15uzipYBnYEogQQXnL/GTCaci24Nx9m83kJSMzCFgahcgt366yyNwF81DUlfzFfYXK/Rid4voIru0elCFcwuRjDgqZbhw4XchcF26lHL8PlSbsPtQEvLcH1JhlqvxqWXU0uDQGso+XH1hnQO1GNgCEP/geEhnWJkuWUxv5xeWxAMFvuoVxUMp+L4kNRf/hsQv1cydB1tDRgMt5Qs514OP8DwDwxh6DuVDDsXbbiA4Y8wJOvpl0Sl9wcu2/AOhgXJDzD8/pL1yChKY3HQEOWRHHx6W+Vls3idZVmapo8Fq9YWeYWXLVqOkAflbLD78zbUPE2XWbbWW2eT3zhz9/au/AKj5pqTDFllc2c4smN4A8PmgKEuMGwOGOoCw+aAoS4wbA4Y6gLD5rBkGJHx4YYkSSToO+hyioSsS0/OprhZSJGof11VjryVADXsyHt6fcopYiYnIR9gPskp6MygHAk3tH1WBUM5BfnsLJa/iKGvLsufh5XMKhFDEolHhhyGMIQhDGEIQxjCEIYwhCEMYQhDGMIQhjCEIQxhCEMYwhCGMCz+9YMrQ3mt1pShvLbszJCuRhvauh2GMIQhDGEIQxjCEIYwhCEMYQhDGMIQhjD821A+sAeGMIThFRuSw7SuzZBu1H91htdfhldnKO8Kc32G8jk5Hhka+poVhjCEIQxhCEMYemQ4kY/XgyEMf7Bh++oNn2AIQxjCEIYwhCEMYahvSPZkh2FFVt4aBoYMH6VjAvmzN4YJDGEIQxjC0FtDElxThi8NGdLtYxsyjGHolaHOPsIuDc/vBR0Y2Aua/EzWWppMTjHpS5D3XCI5RZ9s+R3LKUi32qFhQ8BQG2L4YSZfZWaBjC3D1Ey+ysBQG2KYm8lXmaQxw0cz+SrTmCFbmclXmaHclFozrHLYpw36jRlWOVbYBtPGDN8jMxmr0uNNGYb0BJhGWDZl6KoxTUglNWWYk59OvJnJWQmy8hSwgJ5JpMWGGDJGhojWmXVpGFXOGa/EJ6kejLcM/XxVeSPjiqIq6Z1vXMJzyVHdnA3yNMuy31ue9zwd0O4pcnjxV37/bPO+z7KPfBUKKshCY236hOa+K8fdSdi2+TogvCQAYXCcStsaH+AGb5QkKC1Ft5gd4qT+FSILjbZ1dIbEOXQ6sh7ydK1zWNd05/jRL0XGjD+Po4VPtyKj35PXJ6a9JmcwOx3j+NYXRUuCRUUd+XEvWqmiX4op9+ChIeaGvm8uZRq6LkYm8olFweJmTJnLcmSia+iA3FOOeejIsfhtx+SDJCvMnscHA5sm2P+7MN80N8kXDx967V8N0uttZnr3378rC/DkH7Jo+gAAAABJRU5ErkJggg==',
                  }}
                  resizeMode={'cover'}
                />
              </TouchableOpacity>
            </View>
            <View style={{flex: 1, flexDirection: 'row'}}>
              {props.item.specialPrice > 0 && props.item.isSpecial ? (
                <Text
                  style={{
                    fontSize: 15,
                    color: '#ECA140',

                    fontWeight: 'bold',
                    marginTop: 22,
                    textAlign: rtl ? 'right' : 'left',
                  }}>
                  {t('$')}
                  <Text
                    style={{
                      fontWeight: 'bold',
                      color: '#ECA140',
                      textAlign: rtl ? 'right' : 'left',
                    }}>
                    {props.item.specialPrice.toFixed(2) * props.item.amount}
                  </Text>
                </Text>
              ) : (
                <Text
                  style={{
                    fontSize: 15,
                    color: '#ECA140',

                    fontWeight: 'bold',
                    marginTop: 22,

                    textAlign: rtl ? 'right' : 'left',
                  }}>
                  {t('$')}
                  <Text
                    style={{
                      fontWeight: 'bold',
                      color: '#ECA140',
                      textAlign: rtl ? 'right' : 'left',
                    }}>
                    {(
                      props.item.price -
                      (props.item.price * discount) / 100
                    ).toFixed(2) * props.item.amount}
                  </Text>
                </Text>
              )}

              <TouchableOpacity
                style={{
                  marginTop: 25,
                  marginLeft: 70,
                  borderWidth: 2,
                  borderRadius: 6,
                  borderColor: 'black',
                  padding: 2,
                  width: 25,
                  height: 22,
                }}
                onPress={() => {
                  props.item.amount >= props.item.quantity ||
                  props.item.amount >= props.item.maxOrderQuantity
                    ? console.log('Disabled')
                    : handleProductAmountChange('add', props.item);
                }}>
                <Icon name="plus" size={15} color="#aaa" />
              </TouchableOpacity>
              <TextInput
                // value={String(props.item.amount)}
                value={amount}
                onChangeText={(value) =>
                  // props.updateCartAmount({...props.item, amount: value})
                  setAmount(value)
                }
                style={{
                  height: 35,
                  width: 25,
                  color: '#444',
                  textAlign: 'center',
                  marginLeft: 3,
                  marginTop: 20,
                }}
                keyboardType="number-pad"
              />
              <TouchableOpacity
                style={{
                  marginTop: 25,
                  marginLeft: 2,
                  borderWidth: 2,
                  borderRadius: 6,
                  width: 25,
                  height: 22,
                  borderColor: 'black',
                }}
                onPress={() =>
                  props.item.amount <= props.item.minOrderQuantity
                    ? console.log('Disabled')
                    : handleProductAmountChange('subtract', props.item)
                }>
                <Icon name="minus" size={18} color="#aaa" />
              </TouchableOpacity>
            </View>
          </View>
        </TouchableOpacity>
      </View>
      <View>
        <TouchableOpacity
          onPress={() => {
            props.item.amount >= props.item.quantity ||
            props.item.amount >= props.item.maxOrderQuantity
              ? console.log('Disabled')
              : handleProductAmountChange('add', props.item);
          }}>
          <Icon name="chevron-up" size={25} color="#aaa" />
        </TouchableOpacity>
        <TextInput
          // value={String(props.item.amount)}
          value={amount}
          onChangeText={(value) =>
            // props.updateCartAmount({...props.item, amount: value})
            setAmount(value)
          }
          style={{
            height: 30,
            backgroundColor: '#0000',
            color: '#444',
            textAlign: 'center',
            padding: 0,
            marginBottom: -10,
          }}
          keyboardType="number-pad"
        />
        <TouchableOpacity
          style={{marginTop: 11}}
          onPress={() =>
            props.item.amount <= props.item.minOrderQuantity
              ? console.log('Disabled')
              : handleProductAmountChange('subtract', props.item)
          }>
          <Icon name="chevron-down" size={25} color="#aaa" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  flexRow: {
    display: 'flex',
    flexDirection: 'row',
    width: Window.width < 370 ? '97%' : '97%',
    // backgroundColor: '#0f0'
  },
  flexRowRTL: {
    display: 'flex',
    flexDirection: 'row-reverse',
    width: Window.width < 370 ? '95%' : '96%',
    // backgroundColor: '#0f0'
  },
  cartpage: {
    width: Window.width,
    height: Window.height,
  },
  detail: {
    margin: 15,
    paddingHorizontal: 15,
    backgroundColor: '#fff',
    borderRadius: 3,
    borderWidth: 1,
    borderColor: '#eee',
    elevation: 1,
  },
  cartcard: {
    // paddingHorizontal: 30,
    paddingVertical: 20,
    marginTop: 20,
    borderBottomColor: '#eee',
    borderBottomWidth: 1,
    // position: 'relative',
  },
  viewbtnarea: {
    display: 'flex',
    marginTop: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  viewbtn: {
    backgroundColor: '#7466EF',
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 5,
    elevation: 10,
  },
});

function mapStateToProps(state) {
  return {
    rtlCustomer: state.theme.rtlCustomer,
    cartList: state.cart.cartList,
    userDetails: state.auth.userDetails,
  };
}

export default connect(mapStateToProps, {
  deleteProductFromCart,
  updateCartAmount,
})(CartItem);
