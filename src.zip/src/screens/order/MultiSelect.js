import React, {Component} from 'react';
import {View} from 'react-native';
import MultiSelect from 'react-native-multiple-select';
import {withTranslation} from 'react-i18next';
import {connect} from 'react-redux';

const items = [
  {
    id: 'accepted',
    name: 'Accepted',
  },
  {
    id: 'pending',
    name: 'Pending',
  },
  {
    id: 'cancelled',
    name: 'Canceled',
  },
];

class MultiSelectComponent extends Component {
  state = {
    selectedItems: [],
  };
  onSelectedItemsChange = (selectedItems) => {
    this.setState({selectedItems});
    this.props.onChange(selectedItems);
  };
   
  render() {
    const {selectedItems} = this.state;
    console.log(this.props.rtlCustomer);
    return (
      <View style={{flex: 1}}>
        <MultiSelect
          hideTags
          items={items}
          uniqueKey="id"
          ref={(component) => {
            this.multiSelect = component;
          }}
          onSelectedItemsChange={this.onSelectedItemsChange}
          selectedItems={selectedItems}
          selectText={this.props.t('Status')}
          onChangeInput={(text) => console.log(text)}
          // altFontFamily="ProximaNova-Light"
          tagRemoveIconColor="#7467EF"
          tagBorderColor="#7467EF"
          tagTextColor="#7467EF"
          selectedItemTextColor="#7467EF"
          selectedItemIconColor="#7467EF"
          itemTextColor="#000"
          displayKey="name"
          submitButtonColor="#7467EF"
          fixedHeight={true}
          submitButtonText="Choose"
          styleInputGroup={{display: 'none'}}
          styleTextDropdown={{
            height: 30,
            padding: 5,
            textAlign: 'left',
            fontSize: 18,
            color: '#9E9E9E',
          }}
        />
        {this.multiSelect && (
          <View>{this.multiSelect.getSelectedItemsExt(selectedItems)}</View>
        )}
      </View>
    );
  }
}
// export default withTranslation()(MultiSelectComponent);
function mapStateToProps(state) {
  return {
    rtlCustomer: state.theme.rtlCustomer,
  };
}
export default withTranslation()(connect(mapStateToProps, {
})(MultiSelectComponent));