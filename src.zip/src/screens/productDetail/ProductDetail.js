import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Dimensions,
  ScrollView,
  ActivityIndicator,
  TextInput,
  ToastAndroid,
  Pressable,
  Alert,
  Modal,
} from 'react-native';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import FeatherIcon from 'react-native-vector-icons/Feather';
import { connect } from 'react-redux';
// component
import Body from '../../components/template/body/Body';
import Header from '../../components/template/header/Header';
import Carousel from 'react-native-snap-carousel';
import { addProductToCart, updateCartAmount } from '../../actions/cart';
import { fetchProductDetails } from '../../actions/products';
import { getProductStatus } from '../../utils/';
import { find } from 'lodash';
import { useTranslation } from 'react-i18next';

const Window = Dimensions.get('window');

const ProductDetail = (props) => {
  const { t } = useTranslation();
  const [cartAmount, setCartAmount] = useState(null);
  const [loading, setLoading] = useState(true);
  const [discount, setDiscount] = React.useState(0);
  const [quantity, setQuantity] = useState('0');

  const [modalVisible, setModalVisible] = useState(false);
  const [modalImg, setModalImg] = useState('');
  const [selectedVariant, setSelectedVariant] = useState({});

  const rtl = props.rtlCustomer;

  const [carouselItem, setCarouselItem] = React.useState(0);
  const handleAddProduct = () => {
    let quantityTemp = quantity;
    if (parseInt(quantity) === 0 || quantity === '') {
      quantityTemp = selectedVariant.minOrderQuantity;
    }
    if (quantityTemp > selectedVariant.quantity) {
      ToastAndroid.showWithGravity(
        `${t('The maximum amount available is ')} ${selectedVariant.quantity
        }`,
        ToastAndroid.SHORT,
        ToastAndroid.CENTER,
      );
    } else if (
      selectedVariant.minOrderQuantity >
      selectedVariant.quantity
    ) {
      ToastAndroid.showWithGravity(
        `${t('The maximum amount available is ')} ${selectedVariant.quantity
        }`,
        ToastAndroid.SHORT,
        ToastAndroid.CENTER,
      );
    } else if (quantityTemp < selectedVariant.minOrderQuantity) {
      ToastAndroid.showWithGravity(
        `${t('The minimum order amount should be ')} ${selectedVariant.minOrderQuantity
        }`,
        ToastAndroid.SHORT,
        ToastAndroid.CENTER,
      );
    } else if (quantityTemp > selectedVariant.maxOrderQuantity) {
      ToastAndroid.showWithGravity(
        `${t('The maximum order amount should be ')} ${selectedVariant.maxOrderQuantity
        }`,
        ToastAndroid.SHORT,
        ToastAndroid.CENTER,
      );
    } else {
      props.addProductToCart(
        { ...selectedVariant },
        parseInt(parseInt(quantityTemp)),
      );
    }
  };

  const handleProductAmountChange = (action) => {
    if (action === 'add')
      props.updateCartAmount({
        ...selectedVariant,
        amount: cartAmount + 1,
      });
    else
      props.updateCartAmount({
        ...selectedVariant,
        amount: cartAmount - 1,
      });
  };
  const handleFetchProductDetails = async () => {
    try {
      await props.fetchProductDetails(props.route.params.product._id)
    } catch (err) {

    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    if (props.route.params.hasOwnProperty('product')) {
      handleFetchProductDetails();
      // const discount = props.userDetails?.percentDiscount || 0;
      // setDiscount(discount);
    }
  }, [props.route.params]);
  useEffect(() => {
    let amount =
      find(props.cartList, { _id: selectedVariant._id })?.amount * 1 ||
      0;
    setCartAmount(amount);
    setQuantity(String(amount));
  }, [props.cartList, selectedVariant._id]);
  useEffect(() => {
    if (props.product?.children?.length) {
      setSelectedVariant(props.product.children[0])
    } else {
      setSelectedVariant(props.product)
    }
  }, [props.product])
  useEffect(() => {
    if (props.userDetails.percentDiscount)
      setDiscount(props.userDetails.percentDiscount);
  }, [props.userDetails]);
  // const _renderItem = ({item, index}) => {
  //   return (
  //     <Image
  //       source={
  //         item[index]
  //           ? {uri: item[index]}
  //           : require('../../assets/dummy-product.png')
  //       }
  //       style={styles.productImage}
  //     />
  //   );
  // };
  const CarouselMove = (id) => {
    setCarouselItem(id);
  };
  const _renderItem = ({ item, index }) => {
    return <Image source={{ uri: item }} style={styles.productImage} />;
  };

  if (loading)
    return (
      <ActivityIndicator size="large" color="#000" style={{ marginTop: 20 }} />
    );
  else
    return (
      <Body>
        <ScrollView stickyHeaderIndices={[0]}>
          <Header title="Product Detail" right={false} back={true} />
          <View style={styles.bodyContainer}>
            <View style={styles.detail}>
              <View style={rtl ? styles.flexRowRTL : styles.flexRow}>
                <Text style={[rtl ? styles.HeaderRTL : styles.Header]}>
                  {selectedVariant.productName}
                </Text>
              </View>
              <View style={styles.Divider} />
              {props.product?.children?.length > 0 && (
                <View>
                  <View style={rtl ? styles.rowRTL : styles.row}>
                    <Text
                      style={[
                        styles.label,
                        {
                          textAlign: rtl ? 'right' : 'left',
                          fontWeight: 'bold',
                          fontSize: 14,
                        },
                      ]}>
                      {'Color'}
                    </Text>
                    <Text
                      style={[styles.label, { textAlign: rtl ? 'right' : 'left' }]}>
                      {props.product.children.map(child => child.color).join(", ")}
                    </Text>
                  </View>
                  <View style={rtl ? styles.rowRTL : styles.row}>
                    {props.product.children.map((child, i) => (
                      <Pressable style={[styles.colorWrapper, { borderWidth: child._id === selectedVariant._id ? 2 : 0 }]} key={i} onPress={() => setSelectedVariant(child)}>
                        <View style={[styles.colorBox, { backgroundColor: child.color.toLowerCase() }]} />
                      </Pressable>
                    ))}
                  </View>
                  <View style={rtl ? styles.rowRTL : styles.row}>
                    <Text
                      style={[
                        styles.label,
                        {
                          textAlign: rtl ? 'right' : 'left',
                          fontWeight: 'bold',
                          fontSize: 14,
                        },
                      ]}>
                      {'Size'}
                    </Text>
                  </View>
                  <View style={rtl ? styles.rowRTL : styles.row}>
                    {props.product.children.map((child, i) => (
                      <Pressable
                        style={[styles.sizeWrapper, { borderWidth: child._id === selectedVariant._id ? 2 : 0 }]}
                        key={i}
                        onPress={() => setSelectedVariant(child)}
                      >
                        <Text style={styles.sizeText}>{child.size}</Text>
                      </Pressable>
                    ))}
                  </View>
                </View>
              )}
              <View style={rtl ? styles.flexRowRTL : styles.flexRow}>
                <View
                  style={{
                    display: 'flex',
                    alignItems: rtl ? 'flex-end' : 'flex-start',
                  }}>
                  <View style={rtl ? styles.rowRTL : styles.row}>
                    <Text
                      style={[
                        styles.label,
                        { textAlign: rtl ? 'right' : 'left' },
                      ]}>
                      {t('Serial No.')}:
                    </Text>
                    <Text
                      style={[
                        styles.label,
                        { textAlign: rtl ? 'right' : 'left' },
                      ]}>
                      {selectedVariant.serialNo}
                    </Text>
                  </View>
                  {getProductStatus(selectedVariant.quantity).status === "Stock Out" && (
                    <View style={rtl ? styles.rowRTL : styles.row}>
                      <Text style={styles.label}>{t('Stock')}:</Text>
                      <Text style={styles.label}>
                        {/* {props.route.params.product.quantity} */}
                        {t(
                          getProductStatus(selectedVariant.quantity)
                            .status,
                        )}
                      </Text>
                    </View>
                  )}
                  {/* <View style={rtl ? styles.rowRTL : styles.row}>
                    <Text style={styles.label}> {t('Category')}: </Text>
                    <TouchableOpacity
                      style={[
                        styles.LinkContainer,
                        {borderRightWidth: rtl ? 0 : 1},
                      ]}>
                      <Text style={[styles.Link]}>
                        {' '}
                        {props.route.params.product.category}{' '}
                      </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[
                        styles.LinkContainer,
                        {borderRightWidth: rtl ? 1 : 0},
                      ]}>
                      <Text style={styles.Link}>
                        {' '}
                        {props.route.params.product.subCategory}
                      </Text>
                    </TouchableOpacity>
                  </View> */}
                  <View style={rtl ? styles.rowRTL : styles.row}>
                    <Text style={styles.label}> {t('Price')}: </Text>
                    <View style={{ marginHorizontal: 2 }} />
                    <Text
                      style={[
                        styles.label,
                        { textDecorationLine: 'line-through' },
                      ]}>
                      {selectedVariant.price}
                    </Text>
                    <View style={{ marginHorizontal: 2 }} />
                    <Text style={rtl ? styles.flexRowRTL : styles.flexRow}>
                      {(selectedVariant.specialPrice > 0 && selectedVariant.isSpecial)
                        ? selectedVariant.specialPrice
                        : (
                          selectedVariant.price -
                          (selectedVariant.price * discount) / 100
                        ).toFixed(2)}
                    </Text>
                  </View>
                </View>
                {/* <View style={styles.Divider} /> */}
                <View>
                  <View style={rtl ? styles.countRTL : styles.count}>
                    <TouchableOpacity
                      style={styles.countBtn}
                      onPress={() => {
                        cartAmount >= selectedVariant.quantity ||
                          cartAmount >=
                          selectedVariant.maxOrderQuantity
                          ? console.log('Disabled')
                          : handleProductAmountChange('add');
                      }}>
                      <FontAwesome5 name="plus" size={12} color="#444" />
                    </TouchableOpacity>
                    <View style={styles.countText}>
                      <TextInput
                        value={quantity}
                        style={{
                          color: '#000',
                          textAlign: 'center',
                          textAlignVertical: 'center',
                          padding: 0,
                          fontSize: 14,
                        }}
                        onChangeText={(value) => setQuantity(value)}
                        keyboardType="number-pad"
                      />
                    </View>
                    <TouchableOpacity
                      style={styles.countBtn}
                      onPress={() =>
                        cartAmount <=
                          selectedVariant.minOrderQuantity
                          ? console.log('Disabled')
                          : handleProductAmountChange('substract')
                      }>
                      <FontAwesome5 name="minus" size={12} color="#444" />
                    </TouchableOpacity>
                  </View>
                  <TouchableOpacity
                    style={
                      getProductStatus(selectedVariant.quantity)
                        .status === 'Stock Out' || cartAmount > 0
                        ? rtl
                          ? styles.btnDisabledRTL
                          : styles.btnDisabled
                        : rtl
                          ? styles.btnFillRTL
                          : styles.btnFill
                    }
                    onPress={() =>
                      getProductStatus(selectedVariant.quantity)
                        .status === 'Stock Out' || cartAmount > 0
                        ? console.log('Disabled')
                        : handleAddProduct(selectedVariant)
                    }>
                    <FontAwesome5
                      name="shopping-cart"
                      size={15}
                      color="#fff"
                      style={{ marginHorizontal: 7 }}
                    />
                    <Text style={styles.btnFillText}>{t('Add to cart')}</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
            <View style={styles.detail}>
              <Text style={[rtl ? styles.HeaderRTL : styles.Header]}>
                {' '}
                {t('Summary')}{' '}
              </Text>
              <View style={styles.Divider} />
              <Text style={{ textAlign: rtl ? 'right' : 'left' }}>
                {selectedVariant.description}
              </Text>
              <Text style={{ textAlign: rtl ? 'right' : 'left' }}>
                {selectedVariant.saleDescription}
              </Text>
            </View>
            {/* <View style={styles.flexCenter}>
              <Image
                source={
                  props.route.params.product.images[0]
                    ? {uri: props.route.params.product.images[0]}
                    : require('../../assets/dummy-product.png')
                }
                style={styles.productImage}
              />
            </View> */}
            {/* <Carousel
              data={props.route.params.product.images}
              renderItem={_renderItem}
              sliderWidth={Window.width}
              itemWidth={Window.width}
            /> */}
            {selectedVariant?.images?.length > 0 && (
              <View style={styles.carouselImage}>
                {selectedVariant.images.map((item, i) => (
                  <Pressable
                    onPress={() => {
                      // console.log(item);
                      setModalImg(item);
                      setModalVisible(!modalVisible);
                    }}
                    key={i}
                  >
                    <Image
                      source={{ uri: item }}
                      key={i}
                      style={[
                        styles.carouselImageItem,
                        { display: carouselItem === i ? 'flex' : 'none' },
                      ]}
                    />
                  </Pressable>
                ))}
              </View>
            )}
            <View style={styles.carouselThumbnail}>
              {/* <FlatList
                data={Data}
                style={{flex: 1}}
                keyExtractor={(ite, i) => {
                  i;
                }}
                renderItem={({item}) => (
                  <TouchableOpacity
                    // key={i}
                    style={styles.carouselThumbnailItem}
                    onPress={() => {
                      CarouselMove(i);
                    }}>
                    <Image
                      source={item.img}
                      style={styles.carouselThumbnailItemImage}
                    />
                  </TouchableOpacity>
                )}
                horizontal
              /> */}
              {selectedVariant?.images?.length > 0 && (
                <ScrollView
                  horizontal
                  style={{ display: 'flex', flexDirection: 'row' }}>
                  {/* <View style={styles.carouselThumbnail}></View> */}
                  {selectedVariant.images.map((item, i) => (
                    <TouchableOpacity
                      key={i}
                      style={styles.carouselThumbnailItem}
                      onPress={() => {
                        CarouselMove(i);
                      }}>
                      <Image
                        source={{ uri: item }}
                        style={styles.carouselThumbnailItemImage}
                      />
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              )}
            </View>
          </View>
        </ScrollView>
        <Modal
          animationType="slide"
          transparent={false}
          visible={modalVisible}
          onRequestClose={() => {
            setModalVisible(!modalVisible);
          }}>
          <View style={styles.centeredView}>
            <View style={styles.close}>
              <Pressable
                style={styles.closebtn}
                onPress={() => {
                  setModalVisible(!modalVisible);
                }}>
                <FeatherIcon name="x" size={20} color={'#fff'} />
              </Pressable>
            </View>
            <Image source={{ uri: modalImg }} style={[styles.ModalImage]} />
          </View>
        </Modal>
      </Body>
    );
};

const styles = StyleSheet.create({
  carouselImage: {
    width: Window.width - 30,
    height: 250,
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row',
    overflow: 'hidden',
    marginLeft: 15,
    marginBottom: 15,
    borderRadius: 3,
  },
  carouselImageItem: {
    width: Window.width - 30,
    height: 250,
  },

  carouselThumbnail: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    width: Window.width - 30,
    marginLeft: 15,
  },
  carouselThumbnailItem: {
    width: 70,
    height: 60,
    overflow: 'hidden',
    marginRight: 10,
    marginBottom: 15,
    borderRadius: 3,
  },
  carouselThumbnailItemImage: {
    width: 70,
    height: 60,
  },
  bodyContainer: {
    flex: 1,
    backgroundColor: '#fff',
  },
  flexCenter: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'flex-start',
    // marginVertical: 15,
  },
  flexRow: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  flexRowRTL: {
    display: 'flex',
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
  },
  productImage: {
    width: Window.width,
    height: 250,
  },
  detail: {
    margin: 15,
    padding: 15,
    backgroundColor: '#fff',
    borderRadius: 3,
    borderWidth: 1,
    borderColor: '#eee',
    elevation: 1,
  },
  Header: {
    fontWeight: 'bold',
    fontSize: 20,
    color: '#444',
    letterSpacing: 0.5,
    // backgroundColor: '#000'
    // width: '100%',
  },
  HeaderRTL: {
    fontWeight: 'bold',
    fontSize: 20,
    color: '#444',
    letterSpacing: 0.5,
    // backgroundColor: '#000',
    // width: '100%',
    textAlign: 'right',
  },
  Divider: {
    height: 1.5,
    width: '100%',
    backgroundColor: '#e1e1e1',
    marginVertical: 15,
  },
  row: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    marginVertical: 5,
    flexWrap: 'wrap',
    width: '74%',
    // backgroundColor: '#ff0'
  },
  rowRTL: {
    display: 'flex',
    flexDirection: 'row-reverse',
    justifyContent: 'flex-start',
    alignItems: 'center',
    marginVertical: 5,
    flexWrap: 'wrap',
    width: '74%',
    // backgroundColor: '#ff0'
  },
  label: {
    color: '#777',
    marginHorizontal: 7,
    // backgroundColor: '#f0f'
  },
  Link: {
    color: '#00f',
    textAlign: 'center',
    width: '100%',
  },
  LinkContainer: {
    paddingHorizontal: 7,
    borderRightWidth: 1,
    borderColor: '#00f',
  },
  btnFill: {
    backgroundColor: '#7467EF',
    padding: 10,
    borderRadius: 3,
    // elevation: 10,
    marginTop: 10,
    width: 120,
    display: 'flex',
    flexDirection: 'row',
  },
  btnFillRTL: {
    backgroundColor: '#7467EF',
    padding: 10,
    borderRadius: 3,
    // elevation: 10,
    marginTop: 10,
    width: 120,
    display: 'flex',
    flexDirection: 'row-reverse',
  },
  btnDisabled: {
    backgroundColor: '#ccc',
    padding: 10,
    borderRadius: 3,
    // elevation: 10,
    marginTop: 10,
    width: 120,
    display: 'flex',
    flexDirection: 'row',
  },
  btnDisabledRTL: {
    backgroundColor: '#ccc',
    padding: 10,
    borderRadius: 3,
    // elevation: 10,
    marginTop: 10,
    width: 120,
    display: 'flex',
    flexDirection: 'row-reverse',
  },
  btnFillText: {
    color: '#fff',
    display: 'flex',
  },
  count: {
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row',
    marginVertical: 10,
  },
  countRTL: {
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row-reverse',
    marginVertical: 10,
  },
  countBtn: {
    padding: 10,
    backgroundColor: '#eee',
    borderRadius: 3,
  },
  countText: {
    width: 50,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fafafa',
    height: 35,
    marginTop: 5,
  },

  centeredView: {
    flex: 1,
    width: Window.width,
    height: Window.height,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 0,
    backgroundColor: '#000',
    position: 'relative',
  },
  ModalImage: {
    width: Window.width,
    height: Window.height - 50,
    resizeMode: 'contain',
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  close: {
    width: '100%',
    height: 30,
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'flex-start',
    flexDirection: 'row',
    backgroundColor: '#000',
  },
  closebtn: {
    height: 50,
    width: 50,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
  },
  colorWrapper: {
    width: 40,
    height: 40,
    marginHorizontal: 7,
    borderColor: '#777',
    borderWidth: 0,
    padding: 1,
  },
  colorBox: {
    // backgroundColor: '#000',
    width: '100%',
    height: '100%',
  },
  sizeWrapper: {
    width: 40,
    height: 40,
    marginHorizontal: 7,
    borderColor: '#777',
    borderWidth: 0,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sizeText: {
    fontWeight: 'bold',
    fontSize: 10
  }
});

function mapStateToProps(state) {
  return {
    rtlCustomer: state.theme.rtlCustomer,
    cartList: state.cart.cartList,
    userDetails: state.auth.userDetails,
    product: state.products.product,
  };
}

export default connect(mapStateToProps, {
  addProductToCart,
  updateCartAmount,
  fetchProductDetails
})(ProductDetail);
