import React, {useEffect} from 'react';
import {
  StyleSheet,
  View,
  Text,
  Dimensions,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
const Window = Dimensions.get('window');

import AntIcon from 'react-native-vector-icons/AntDesign';
import {connect} from 'react-redux';
import {fetchOrderDetails} from '../../actions/orders';
import OrderCard from './component/OrderCard';
import moment from 'moment';
// components
import Body from '../../components/template/body/Body';
import Header from '../../components/template/header/Header';
import {useTranslation} from 'react-i18next';

const OrderDetail = (props) => {
  const {t} = useTranslation();
  const rtl = props.rtlCustomer;
  useEffect(() => {
    props.fetchOrderDetails(props.route.params.id);
  }, []);
  const fetchSubTotal = (items) => {
    let subtotal = 0;
    props.order.orderDetails.items.map((item) => {
      subtotal += item.price * item.unit;
    });
    return subtotal;
  };
  const fetchDiscountAmount = () => {
    return parseFloat(
      (fetchSubTotal() * props.order.orderDetails.percentDiscount) / 100,
    ).toFixed(2);
  };
  if (props.loading)
    return (
      <ActivityIndicator size="large" color="#000" style={{marginTop: 20}} />
    );
  else
    return (
      <Body>
        <Header title="Order Dtetail" back={true} />
        {props.order.hasOwnProperty('_id') && (
          <ScrollView>
            <View style={styles.detail}>
              <View
                style={[
                  rtl ? styles.flexRowRTL : styles.flexRow,
                  styles.orderinfo,
                ]}>
                <View style={{flex: 1}}>
                  <Text
                    style={{
                      fontWeight: 'bold',
                      fontSize: 14,
                      marginBottom: 8,
                      textAlign: rtl ? 'right' : 'left',
                    }}>
                    {t('Order Info')}
                  </Text>
                  <Text
                    style={{
                      fontSize: 16,
                      color: '#777',
                      textAlign: rtl ? 'right' : 'left',
                    }}>
                    {t('Order Number')}
                  </Text>
                  {/* <Text style={{fontSize: 16, marginBottom: 8, color: '#777'}}></Text> */}
                  <Text
                    style={{
                      fontSize: 16,
                      color: '#777',
                      textAlign: rtl ? 'right' : 'left',
                    }}>
                    {props.order._id}
                  </Text>
                </View>
                <View style={{flex: 1, backgroundColor: '#f000'}}>
                  <View
                    style={[
                      rtl ? styles.flexRowRTL : styles.flexRow,
                      {
                        justifyContent: 'flex-start',
                        marginBottom: 8,
                        marginLeft: 0,
                      },
                    ]}>
                    <Text
                      style={{
                        fontWeight: 'bold',
                        fontSize: 14,
                        textAlign: rtl ? 'right' : 'left',
                      }}>
                      {t('Order status')}:{' '}
                    </Text>
                    <Text
                      style={{
                        fontSize: 16,
                        color: '#777',
                        textTransform: 'capitalize',
                        textAlign: rtl ? 'right' : 'left',
                      }}>
                      {t(props.order.orderStatus)}
                    </Text>
                  </View>
                  <View style={[{justifyContent: 'flex-start', marginLeft: 0}]}>
                    <Text
                      style={{
                        fontWeight: 'bold',
                        fontSize: 14,
                        textAlign: rtl ? 'right' : 'left',
                      }}>
                      {t('Order date')}:
                    </Text>
                    <Text
                      style={{
                        fontSize: 16,
                        color: '#777',
                        textAlign: rtl ? 'right' : 'left',
                      }}>
                      {moment
                        .utc(props.order.createdAt)
                        .local()
                        .format('MMM DD, YYYY | HH:mm A')}
                    </Text>
                  </View>
                </View>
              </View>

              <View style={styles.Divider} />

              <View style={[rtl ? styles.flexRowRTL : styles.flexRow]}>
                <View style={{flex: 1, backgroundColor: '#f000'}}>
                  <Text
                    style={{
                      fontWeight: 'bold',
                      fontSize: 14,
                      textAlign: rtl ? 'right' : 'left',
                    }}>
                    {t('Order To')}
                  </Text>
                  <Text
                    style={{
                      fontSize: 16,
                      marginTop: 8,
                      color: '#777',
                      textAlign: rtl ? 'right' : 'left',
                    }}>
                    {props.order.orderDetails.buyer.firstName}{' '}
                    {props.order.orderDetails.buyer.lastName}
                  </Text>
                  <Text
                    style={{
                      fontSize: 16,
                      marginTop: 4,
                      color: '#777',
                      textAlign: rtl ? 'right' : 'left',
                    }}>
                    {props.order.orderDetails.buyer.company}
                  </Text>
                  <Text
                    style={{
                      fontSize: 16,
                      marginTop: 4,
                      color: '#777',
                      textAlign: rtl ? 'right' : 'left',
                    }}>
                    {props.order.orderDetails.buyer.mobile}
                  </Text>
                </View>
                <View style={{flex: 1, backgroundColor: '#f000'}}>
                  <Text
                    style={{
                      fontWeight: 'bold',
                      fontSize: 14,
                      textAlign: 'left',
                      textAlign: rtl ? 'right' : 'left',
                    }}>
                    {t('Order From')}
                  </Text>
                  <Text
                    style={{
                      fontSize: 16,
                      textAlign: 'left',
                      marginTop: 2,
                      color: '#777',
                      textAlign: rtl ? 'right' : 'left',
                    }}>
                    {props.order.orderDetails.seller.firstName}{' '}
                    {props.order.orderDetails.seller.lastName}
                  </Text>
                  <Text
                    style={{
                      fontSize: 16,
                      textAlign: 'left',
                      marginTop: 2,
                      color: '#777',
                      textAlign: rtl ? 'right' : 'left',
                    }}>
                    {props.order.orderDetails.seller.companyName}
                  </Text>
                  <Text
                    style={{
                      fontSize: 16,
                      textAlign: 'left',
                      marginTop: 2,
                      color: '#777',
                      textAlign: rtl ? 'right' : 'left',
                    }}>
                    {props.order.orderDetails.seller.phoneNumber}
                  </Text>
                </View>
              </View>
              <View style={{marginVertical: 10}} />

              <View style={styles.Divider} />
              {/* table */}
              <View>
                {/* <View
                  style={[
                    rtl ? styles.flexRowRTL : styles.flexRow,
                    {
                      flex: 1,
                      borderBottomWidth: 1,
                      borderColor: '#bbb',
                    },
                  ]}>
                  <View style={{flex: 1}}>
                    <Text
                      style={[
                        styles.orderdata,
                        {
                          fontWeight: 'bold',
                          paddingTop: 2,
                          paddingBottom: 18,
                          textAlign: rtl ? 'right' : 'left',
                        },
                      ]}>
                      #
                    </Text>
                  </View>
                  <View style={{flex: 1}}>
                    <Text
                      style={[
                        styles.orderdata,
                        {
                          fontWeight: 'bold',
                          marginTop: -16.5,
                          textAlign: rtl ? 'right' : 'left',
                        },
                      ]}>
                      {t("Item Name")}
                    </Text>
                  </View>
                  <View style={{flex: 1}}>
                    <Text
                      style={[
                        styles.orderdata,
                        {
                          fontWeight: 'bold',
                          marginTop: -16.5,
                          textAlign: rtl ? 'right' : 'left',
                        },
                      ]}>
                      {t("Unit Price")}
                    </Text>
                  </View>
                  <View style={{flex: 1}}>
                    <Text
                      style={[
                        styles.orderdata,
                        {
                          fontWeight: 'bold',
                          paddingTop: 2,
                          paddingBottom: 18,
                          textAlign: rtl ? 'right' : 'left',
                        },
                      ]}>
                      {t("Unit")}
                    </Text>
                  </View>
                  <View style={{flex: 1}}>
                    <Text
                      style={[
                        styles.orderdata,
                        {
                          fontWeight: 'bold',
                          paddingTop: 2,
                          paddingBottom: 18,
                          textAlign: rtl ? 'right' : 'left',
                        },
                      ]}>
                      {t("Cost")}
                    </Text>
                  </View>
                </View> */}
                {props.order.orderDetails.items.map((item, i) => (
                  <React.Fragment key={i}>
                    <OrderCard item={item} i={i} />
                    {/* <View
                  style={{
                    elevation: 5,
                    borderRadius: 5,
                    backgroundColor: '#fff',
                    marginVertical: 10,
                  }}
                  key={i}>
                  <View style={[rtl ? styles.flexRowRTL : styles.flexRow]}>
                    <View>
                      <Text
                        style={[
                          styles.orderdata,
                          {fontWeight: 'bold', fontSize: 16},
                        ]}>
                        {i + 1} .
                      </Text>
                    </View>
                    <View style={{flex: 1}}>
                      <Text
                        numberOfLines={1}
                        style={[
                          styles.orderdata,
                          {fontWeight: 'bold', fontSize: 16},
                        ]}>
                        {item.name}
                      </Text>
                    </View>
                  </View>
                  <View
                    style={[
                      styles.Divider,
                      {
                        marginVertical: 3,
                        marginHorizontal: 10,
                        width: '94%',
                      },
                    ]}
                  />

                  <View style={[rtl ? styles.flexRowRTL : styles.flexRow]}>
                    <View
                      style={[
                        {
                          flex: 1,
                          alignItems: rtl ? 'center' : 'center',
                        },
                      ]}>
                      <View>
                        <Text
                          style={[styles.orderdata, {fontWeight: 'bold'}]}>
                          {t('Unit Price')}
                        </Text>
                      </View>
                      <View style={{flex: 1, marginTop: -10}}>
                        <Text style={styles.orderdata}>{item.price}</Text>
                      </View>
                    </View>

                    <View
                      style={[
                        {
                          flex: 1,
                          alignItems: rtl ? 'center' : 'center',
                        },
                      ]}>
                      <View>
                        <Text
                          style={[styles.orderdata, {fontWeight: 'bold'}]}>
                          {t('Unit')}
                        </Text>
                      </View>
                      <View style={{flex: 1, marginTop: -10}}>
                        <Text style={styles.orderdata}>{item.unit}</Text>
                      </View>
                    </View>

                    <View
                      style={[
                        {
                          flex: 1,
                          alignItems: rtl ? 'center' : 'center',
                        },
                      ]}>
                      <View style={{flex: 1}}>
                        <Text
                          style={[styles.orderdata, {fontWeight: 'bold'}]}>
                          {t('Cost')}:
                        </Text>
                      </View>
                      <View style={{flex: 1, marginTop: -10}}>
                        <Text style={[styles.orderdata]}>
                          {item.price * item.unit}
                        </Text>
                      </View>
                    </View>
                  </View>
                </View> */}
                  </React.Fragment>
                ))}
              </View>
              {/* table */}
              <View style={{marginVertical: 20}} />
              <View>
                <View style={rtl ? styles.rowSpacedRTL : styles.rowSpaced}>
                  <Text style={{fontSize: 16}}>{t('Sub Total')}:</Text>
                  <Text style={{fontSize: 16}}>{parseFloat(fetchSubTotal()).toFixed(2)}</Text>
                </View>
                <View style={{marginVertical: -5}} />

                <View style={styles.Divider} />
                <View style={{marginVertical: -5}} />

                <View style={rtl ? styles.rowSpacedRTL : styles.rowSpaced}>
                  <Text style={{fontSize: 16, marginTop: 8}}>
                    {t('Discount')} ({props.order.orderDetails.percentDiscount}
                    %):
                  </Text>
                  <Text style={{fontSize: 16, marginTop: 8}}>
                    {/* - {fetchDiscountAmount()} */}
                    {props.order.orderDetails.discount ? - parseFloat(props.order.orderDetails.discount).toFixed(2) : - parseFloat(fetchDiscountAmount()).toFixed(2)}
                  </Text>
                </View>
                <View style={{marginVertical: -5}} />

                <View style={styles.Divider} />
                <View style={{marginVertical: -5}} />

                <View style={rtl ? styles.rowSpacedRTL : styles.rowSpaced}>
                  <Text
                    style={{fontSize: 16, marginTop: 8, fontWeight: 'bold'}}>
                    {t('Grand Total')}:
                  </Text>
                  <Text
                    style={{fontSize: 16, marginTop: 8, fontWeight: 'bold'}}>
                    {/* {(fetchSubTotal() - fetchDiscountAmount()).toFixed(2)} */}
                    {props.order.orderDetails.grandTotal ? parseFloat(props.order.orderDetails.grandTotal).toFixed(2) : (fetchSubTotal() - fetchDiscountAmount()).toFixed(2)}
                  </Text>
                </View>
              </View>
            </View>
          </ScrollView>
        )}
      </Body>
    );
};

const styles = StyleSheet.create({
  flexRow: {
    display: 'flex',
    flexDirection: 'row',
    width: '100%',
  },
  flexRowRTL: {
    display: 'flex',
    flexDirection: 'row-reverse',
    width: '100%',
  },
  rowSpaced: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    display: 'flex',
    width: '100%',
  },
  rowSpacedRTL: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    display: 'flex',
    width: '100%',
  },
  orderDetail: {
    width: Window.width,
    height: Window.height,
  },
  detail: {
    margin: 15,
    padding: 15,
    backgroundColor: '#fff',
    borderRadius: 3,
    borderWidth: 1,
    borderColor: '#eee',
    elevation: 1,
  },
  Divider: {
    height: 1.5,
    width: '100%',
    backgroundColor: '#e1e1e1',
    marginVertical: 15,
  },
  orderinfo: {
    // paddingHorizontal: 30,
    // paddingVertical: 20,
    justifyContent: 'space-between',
    marginTop: 10,
    // borderBottomWidth: 2,
    // borderColor: '#ddd',
  },
  orderto: {
    paddingHorizontal: 30,
    paddingVertical: 20,
    justifyContent: 'space-between',
    marginTop: 10,
    marginBottom: 5,
  },
  orderdata: {
    // paddingHorizontal: 10,
    // paddingVertical: 10,
    // borderBottomWidth: 1,
    // borderColor: '#bbb',
    color: '#000'
  },
  total: {
    paddingHorizontal: 30,
    paddingTop: 5,
    paddingBottom: 20,
    justifyContent: 'flex-end',
  },
  Viewbtn: {
    flex: 1,
    marginTop: 15,
    // marginLeft: 0,
    borderWidth: 1,
    backgroundColor: '#7467EF',
    borderColor: '#7467EF',
    paddingVertical: 13,
    // borderRadius: 5,
    display: 'flex',
    justifyContent: 'center',
    alignContent: 'center',
    flexDirection: 'row',
    elevation: 2,
    height: 50,
  },
  ViewbtnDisabled: {
    flex: 1,
    marginTop: 15,
    // marginLeft: 0,
    borderWidth: 1,
    backgroundColor: '#ccc',
    borderColor: '#ccc',
    paddingVertical: 13,
    // borderRadius: 5,
    display: 'flex',
    justifyContent: 'center',
    alignContent: 'center',
    flexDirection: 'row',
    elevation: 2,
    height: 50,
  },
  deletebtn: {
    // flex: 1,
    width: 95,
    marginTop: 15,
    // marginLeft: 0,
    // marginHorizontal: 5,
    borderWidth: 1,
    backgroundColor: '#FF6666',
    borderColor: '#FF6666',
    paddingVertical: 13,
    // borderRadius: 5,
    display: 'flex',
    justifyContent: 'center',
    alignContent: 'center',
    flexDirection: 'row',
    elevation: 2,
    height: 50,
  },
  deletebtnDisabled: {
    width: 95,
    marginTop: 15,
    borderWidth: 1,
    backgroundColor: '#ccc',
    borderColor: '#ccc',
    paddingVertical: 13,
    display: 'flex',
    justifyContent: 'center',
    alignContent: 'center',
    flexDirection: 'row',
    elevation: 2,
    height: 50,
  },
});

function mapStateToProps(state) {
  return {
    order: state.orders.order,
    loading: state.orders.loading,
    rtlCustomer: state.theme.rtlCustomer,
  };
}
export default connect(mapStateToProps, {
  fetchOrderDetails,
})(OrderDetail);
