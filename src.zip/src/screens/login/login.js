import React, {useState} from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image,
  TextInput,
  Dimensions,
  TouchableOpacity,
  CheckBox,
  ActivityIndicator,
} from 'react-native';
import {connect} from 'react-redux';
import {checkLogin} from '../../actions/auth';
import validateLogin from '../../validators/auth/login';
import Feather from 'react-native-vector-icons/Feather';
const Window = Dimensions.get('window');

const Login = (props) => {
  const [state, setState] = useState({
    email: '',
    password: '',
    loading: false,
    errors: {},
    rememberMe: false,
  });
  const [error, setError] = React.useState('');

  const handleCheckLogin = async () => {
    setState({...state, loading: true});
    const {errors, isValid} = validateLogin(state);
    // check validations
    if (!isValid) {
      setState({...state, errors});
      return;
    }
    try {
      const resp = await props.checkLogin({
        email: state.email,
        password: state.password,
      });
      console.log(resp);
    } catch (err) {
      console.log(err);
      setError('Invalid Email/Password');
    } finally {
      setState({...state, loading: false});
    }
  };
  return (
    <>
      <View style={styles.body}>
        {/* <View style={styles.topSection}>
          <Image source={require('../../assets/v2.png')} style={styles.logo} />
          <Text style={styles.header}>Vendup</Text>
        </View> */}
        <View style={styles.topSection}>
          <Image
            source={require('../../assets/vendup-logo.png')}
            style={styles.logo}
          />
          <Text style={styles.header}>Vendup</Text>
        </View>

        <View style={styles.card}>
          {/* <Image
            style={styles.img}
            // source={require('../../assets/login-signup/dreamer.png')}
            source={require('../../assets/v2.png')}
          /> */}
          <Text style={{color: '#ffffff', fontSize: 18, marginBottom: 20}}>
            Login{' '}
          </Text>

          <View style={{width: '100%'}}>
            <Image
              source={require('../../assets/mail.png')}
              style={{position: 'absolute', zIndex: 10000, bottom: 28, left: 7}}
            />
            <TextInput
              style={styles.input}
              placeholder="Email"
              placeholderTextColor="#fff"
              onChangeText={(email) => setState({...state, email})}
            />
          </View>
          {state.errors.email && (
            <Text style={styles.errorMsg}>{state.errors.email}</Text>
          )}

          <View style={{width: '100%'}}>
            <Image
              source={require('../../assets/lock.png')}
              style={{position: 'absolute', zIndex: 10000, bottom: 28, left: 7}}
            />
            <TextInput
              style={styles.input}
              placeholder="Password"
              placeholderTextColor="#fff"
              onChangeText={(password) => setState({...state, password})}
              secureTextEntry={true}
            />
          </View>

          {state.errors.password && (
            <Text style={styles.errorMsg}>{state.errors.password}</Text>
          )}
          <TouchableOpacity
            style={styles.checkarea}
            onPress={() => {
              setState({...state, rememberMe: !state.rememberMe});
            }}>
            {/* <CheckBox
              style={[styles.check, {marginTop: -5}]}
              value={state.rememberMe}
              onValueChange={(value) => setState({...state, rememberMe: value})}
            /> */}
            <View
              style={{
                width: 20,
                height: 20,
                borderWidth: 1,
                borderRadius: 3,
                marginRight: 10,
                borderColor: '#fff',
              }}>
              {state.rememberMe && (
                <Feather name="check" size={18} color="#fff" />
              )}
            </View>
            <Text style={{color: '#fff'}}>Remember Me</Text>
          </TouchableOpacity>
        </View>

        <View style={{marginTop: 20}}>
          <View style={styles.loginBtns}>
            <TouchableOpacity
              style={{
                backgroundColor: '#ECA140',
                flex: 1,
                marginHorizontal: 20,
                borderRadius: 4,
                paddingVertical: 20,
              }}
              onPress={() => {
                handleCheckLogin();
              }}
              disabled={state.loading}>
              {state.loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text
                  style={{color: '#fff', textAlign: 'center', fontSize: 16}}>
                  Login
                </Text>
              )}
            </TouchableOpacity>
            {/* <Text style={styles.or}>or</Text>
            <TouchableOpacity
              style={[styles.btn, styles.signup]}
              onPress={() => {
                props.navigation.navigate('Singup');
              }}>
              <Text style={{color: '#000'}}>Sign Up</Text>
            </TouchableOpacity> */}
          </View>
        </View>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  body: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: Window.width,
    height: Window.height,
    backgroundColor: '#1A1D2F',
  },
  card: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: Window.width - 30,
    padding: 25,
    backgroundColor: '#313444',
    borderRadius: 12,
  },
  checkarea: {
    display: 'flex',
    flexDirection: 'row',
    width: '100%',
    // borderWidth: 1,
    // borderColor: '#fff',
    // marginBottom: 12,
    marginTop: 20,
  },
  img: {
    width: 210,
    height: 140,
    marginBottom: 30,
  },
  input: {
    // flex:1,
    width: '100%',
    borderRadius: 5,
    // paddingHorizontal: 10,
    color: '#fff',
    paddingLeft: 40,
    marginBottom: 18,
    backgroundColor: '#5A5D69',
    height: 40,
  },
  loginBtns: {
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
  },
  or: {
    marginTop: 10,
    marginLeft: 18,
  },
  btn: {
    borderRadius: 7,
    paddingHorizontal: 18,
    paddingVertical: 8,
    height: 38,
  },
  signin: {
    backgroundColor: '#7467ef',
  },
  topSection: {
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    // flexDirection: 'row',
    padding: 15,
    bottom: 30,
    // marginTop: -100,
    // marginBottom: 30,
  },
  logo: {
    width: 110,
    height: 85,
    marginBottom: 10,
  },
  header: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  errorMsg: {
    color: '#f00',
    letterSpacing: 1,
    marginBottom: 10,
    textAlign: 'left',
  },
});

function mapStateToProps(state) {
  return {
    isLogin: state.auth.isLogin,
  };
  [];
}

export default connect(mapStateToProps, {
  checkLogin,
})(Login);
