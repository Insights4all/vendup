import {
    SHOP_LOADING,
    SHOP_SET_DATA,
    SHOP_SET_DETAIL,
    SHOP_SET_ERROR,
    SHOP_SET_VENDORS,
    SHOP_SEARCH_PRODUCT,
    SHOP_FILTER_PRODUCTS,
    SHOP_SET_FILTERS,
    SHOP_RESET_FILTERS,
    SHOP_SET_ACTIVE_VENDOR_ID
  } from '../constants/shop';
  import { shopService } from '../service/shopService';
  import {SetAuthLogout} from "./auth";

  export const setData = (data) => ({
    type: SHOP_SET_DATA,
    payload: data,
  });
  export const setLoading = status => ({
    type: SHOP_LOADING,
    payload: status
  });
  export const setError = data => ({
    type: SHOP_SET_ERROR,
    payload: data
  });
  export const setDetail = (data) => ({
    type: SHOP_SET_DETAIL,
    payload: data,
  });
  export const setVendors = (data) => ({
    type: SHOP_SET_VENDORS,
    payload: data,
  });
  export const searchProduct = (data) => ({
    type: SHOP_SEARCH_PRODUCT,
    payload: data,
  });
  export const filterProduct = (data) => ({
    type: SHOP_FILTER_PRODUCTS,
    payload: data,
  });
  export const setFilters = (data) => ({
    type: SHOP_SET_FILTERS,
    payload: data,
  });
  export const resetFilters = (data) => ({
    type: SHOP_RESET_FILTERS,
    payload: data,
  });
  export const setActiveVendorId = (data) => ({
    type: SHOP_SET_ACTIVE_VENDOR_ID,
    payload: data,
  });
  export const fetchShop = (vendorId) => async(dispatch) => {
    return new Promise(async(resolve, reject) => {
      await dispatch(setLoading(true));
      shopService.fetchShop(vendorId).then(async (res) => {
        await dispatch(setData(res.products));
        resolve(res);
      }).catch((err) => {
        if(err.response.status === 500){
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err))
        reject(err)
      }).finally(()=>{
        dispatch(setLoading(false));
      })
    })
  };
  export const fetchShopDetails = (id) => async(dispatch) => {
    return new Promise(async(resolve, reject) => {
      await dispatch(setLoading(true));
      shopService.fetchShopDetails(id).then(async (res) => {
        await dispatch(setDetail(res));
        resolve(res);
      }).catch((err) => {
        if(err.response.status === 500){
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err))
        reject(err)
      }).finally(()=>{
        dispatch(setLoading(false));
      })
    })
  };
  export const fetchVendors = () => async(dispatch) => {
    return new Promise(async(resolve, reject) => {
      await dispatch(setLoading(true));
      shopService.fetchVendors().then(async (res) => {
        await dispatch(setVendors(res));
        resolve(res);
      }).catch((err) => {
        if(err.response.status === 500){
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err))
        reject(err)
      }).finally(()=>{
        dispatch(setLoading(false));
      })
    })
  };