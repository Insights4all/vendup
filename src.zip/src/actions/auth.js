import {
  AUTH_LOADING,
  AUTH_SUCCESS,
  AUTH_LOGOUT,
  AUTH_ROLE
} from '../constants/auth';
import { authService } from '../service/authService';
import {resetTheme} from "./theme";
import {resetFilters} from "./shop";
import AsyncStorage from '@react-native-async-storage/async-storage';

export const setRole = (role) => ({
  type: AUTH_ROLE,
  payload: role,
});
export const setLoading = status => ({
  type: AUTH_LOADING,
  payload: status
});
export const setAuthSuccess = data => ({
  type: AUTH_SUCCESS,
  payload: data
});
export const SetAuthLogout = () => async(dispatch) => {
  dispatch(resetTheme());
  dispatch(resetFilters());
  dispatch({
    type: AUTH_LOGOUT
  })
}
export const checkLogin = (formData) => async(dispatch) => {
  return new Promise(async(resolve, reject) => {
    await dispatch(setLoading(true));
    authService.checkLogin(formData).then(async (res) => {
      await dispatch(setAuthSuccess(res));
      resolve(res);
    }).catch((err) => {
      reject(err)
    }).finally(()=>{
      dispatch(setLoading(false));
    })
  })
};