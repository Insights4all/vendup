import {
  ADD_PRODUCT_TO_CART,
  DELETE_PRODUCT_FROM_CART,
  UPDATE_CART_AMOUNT,
} from '../constants/cart';

export const addProductToCart = (product, amount) => (dispatch, getState) => {
  let {cart} = getState();
  let {cartList = []} = cart;
  let existingProduct = cartList.find((p) => p._id === product._id);
  if (existingProduct) {
    existingProduct.amount = amount || existingProduct.amount++;
    dispatch(updateCartAmount(existingProduct));
  } else {
    product.amount = amount || product.minOrderQuantity || 1;
    cartList.push(product);
    dispatch({
      type: ADD_PRODUCT_TO_CART,
      payload: cartList,
    });
  }
};

export const deleteProductFromCart = (product) => (dispatch, getState) => {
  let {cart} = getState();
  let {cartList = []} = cart;
  let filteredCartList = cartList.filter((p) => p._id !== product._id);
  dispatch({
    type: DELETE_PRODUCT_FROM_CART,
    payload: filteredCartList,
  });
};

export const clearProductCart = () => (dispatch) => {
  dispatch({
    type: DELETE_PRODUCT_FROM_CART,
    payload: [],
  });
};

export const updateCartAmount = (product) => (dispatch, getState) => {
  let {cart} = getState();
  let {cartList = []} = cart;
  let existingProduct = cartList.filter((p) => p._id === product._id);
  if (existingProduct.length) {
    let updatedCartList = cartList.map((p) => {
      if (p._id === product._id) {
        return product;
      } else return p;
    });
    dispatch({
      type: UPDATE_CART_AMOUNT,
      payload: updatedCartList,
    });
  }else{
    dispatch(addProductToCart(product))
  }
};
