import {
    CUSTOMERS_LOADING,
    CUSTOMERS_SET_DATA,
    CUSTOMERS_SET_DETAIL,
    CUSTOMERS_SET_ERROR,
    CUSTOMERS_APPLY_FILTER,
    CUSTOMERS_SET_FILTERS,
    CUSTOMERS_RESET_FILTERS,
    CUSTOMERS_SEARCH
  } from '../constants/customers';
  import { customerService } from '../service/customerService';
  import {SetAuthLogout} from "./auth";

  export const setData = (data) => ({
    type: CUSTOMERS_SET_DATA,
    payload: data,
  });
  export const setLoading = status => ({
    type: CUSTOMERS_LOADING,
    payload: status
  });
  export const setError = data => ({
    type: CUSTOMERS_SET_ERROR,
    payload: data
  });
  export const applyFilter = (data) => async (dispatch) => {
    dispatch({
      type: CUSTOMERS_APPLY_FILTER,
      payload: data,
    })
  }
  export const setFilters = (data) => ({
    type: CUSTOMERS_SET_FILTERS,
    payload: data,
  });
  export const resetFilters = (data) => ({
    type: CUSTOMERS_RESET_FILTERS,
    payload: data,
  });
  export const searchCustomers = (data) => async (dispatch) => {
    dispatch({
      type: CUSTOMERS_SEARCH,
      payload: data
    })
  }
  
  export const fetchVendorCustomers = () => async(dispatch) => {
    return new Promise(async(resolve, reject) => {
      await dispatch(setLoading(true));
      customerService.fetchVendorCustomers().then(async (res) => {
        await dispatch(setData(res));
        resolve(res);
      }).catch((err) => {
        if(err.response.status === 500){
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err))
        reject(err)
      }).finally(()=>{
        dispatch(setLoading(false));
      })
    })
  };
  export const deleteCustomer = (id) => async(dispatch) => {
    return new Promise(async(resolve, reject) => {
      await dispatch(setLoading(true));
      customerService.deleteCustomer(id).then(async (res) => {
        await dispatch(fetchVendorCustomers());
        resolve(res);
      }).catch((err) => {
        if(err.response.status === 500){
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err))
        reject(err)
      }).finally(()=>{
        dispatch(setLoading(false));
      })
    })
  };
  export const createCustomer = (formData) => async(dispatch) => {
    return new Promise(async(resolve, reject) => {
      await dispatch(setLoading(true));
      customerService.createCustomer(formData).then(async (res) => {
        await dispatch(fetchVendorCustomers());
        resolve(res);
      }).catch((err) => {
        if(err.response.status === 500){
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err))
        reject(err)
      }).finally(()=>{
        dispatch(setLoading(false));
      })
    })
  };
  export const updateCustomer = (formData) => async(dispatch) => {
    return new Promise(async(resolve, reject) => {
      await dispatch(setLoading(true));
      customerService.updateCustomer(formData).then(async (res) => {
        await dispatch(fetchVendorCustomers());
        resolve(res);
      }).catch((err) => {
        if(err.response.status === 500){
          dispatch(SetAuthLogout());
        }
        dispatch(setError(err))
        reject(err)
      }).finally(()=>{
        dispatch(setLoading(false));
      })
    })
  };