import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {API_URL} from '../config';

function fetchVendorCustomers() {
  return new Promise(async (resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
      .get(API_URL + 'api/getMyCustomers', {
        headers: {
          Authorization: `bearer ${token}`,
        },
      })
      .then(async (response) => {
        if (response.data.status === 200) resolve(response.data.data);
        else resolve([]);
      })
      .catch((err) => {
        reject(err);
      });
  });
}
function deleteCustomer(idList) {
  return new Promise(async (resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
      .delete(`${API_URL}api/deleteCustomer`, {
        headers: {
          Authorization: `bearer ${token}`,
        },
        data: idList,
      })
      .then(async (response) => {
        resolve(response.data.data);
      })
      .catch((err) => {
        reject(err);
      });
  });
}
function createCustomer(formData) {
  return new Promise(async (resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
    .post(`${API_URL}api/createCustomer`, formData, {
      headers: {
        Authorization: `bearer ${token}`,
      }
    })
    .then(async (response) => {
      resolve(response.data.data);
    })
    .catch((err) => {
      reject(err);
    });
  });
}
function updateCustomer(formData) {
  return new Promise(async (resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
    .put(`${API_URL}api/updateCustomer`, formData, {
      headers: {
        Authorization: `bearer ${token}`,
      }
    })
    .then(async (response) => {
      console.log(response.data);
      resolve(response.data.data);
    })
    .catch((err) => {
      reject(err);
    });
  });
}
export const customerService = {
  fetchVendorCustomers,
  deleteCustomer,
  createCustomer,
  updateCustomer
};
