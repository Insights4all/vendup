import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {API_URL} from '../config';

function fetchProducts(vendorId) {
  return new Promise(async (resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
      .get(API_URL + 'api/getMyProducts', {
        headers: {
          Authorization: `bearer ${token}`,
        },
      })
      .then(async (response) => {
        if (response.data.status === 200) resolve(response.data.data);
        else resolve([]);
      })
      .catch((err) => {
        reject(err);
      });
  });
}
function fetchProductDetails(id) {
  return new Promise(async (resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
      .get(`${API_URL}api/product/${id}`, {
        headers: {
          Authorization: `bearer ${token}`,
        },
      })
      .then(async (response) => {
        if (response.data.status === 200) resolve(response.data.data);
        else resolve({});
      })
      .catch((err) => {
        console.log(err);
        reject(err);
      });
  });
}
function deleteProduct(idList) {
  return new Promise(async (resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
      .delete(`${API_URL}api/deleteProduct`, {
        headers: {
          Authorization: `bearer ${token}`,
        },
        data: idList,
      })
      .then(async (response) => {
        resolve(response.data.data);
      })
      .catch((err) => {
        reject(err);
      });
  });
}
function createProduct(formData) {
  return new Promise(async (resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
    .post(`${API_URL}api/addNewProduct`, formData, {
      headers: {
        Authorization: `bearer ${token}`,
      },
    })
    .then(async (response) => {
      resolve(response.data.data);
    })
    .catch((err) => {
      reject(err);
    });
  });
}
function updateProduct(formData) {
  return new Promise(async (resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
    .put(`${API_URL}api/updateProduct`, formData, {
      headers: {
        Authorization: `bearer ${token}`,
      }
    })
    .then(async (response) => {
      resolve(response.data.data);
    })
    .catch((err) => {
      reject(err);
    });
  });
}
export const productService = {
  fetchProducts,
  fetchProductDetails,
  deleteProduct,
  createProduct,
  updateProduct
};
