import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {API_URL} from '../config';

function fetchVendorOrders() {
  return new Promise(async(resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
    .get(API_URL + 'api/getMyOrdersVendor', {
        headers: {
            Authorization: `bearer ${token}`
        }
    })
    .then(async (response) => {
      if(response.data.status === 200)
        resolve(response.data.data);
      else
        resolve([]);
    })
    .catch((err) => {
        reject(err);
    });
  });
}
function fetchOrderDetails(id) {
  return new Promise(async(resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
    .get(`${API_URL}api/getOrder/${id}`, {
        headers: {
            Authorization: `bearer ${token}`
        }
    })
    .then(async (response) => {
      if(response.data.status === 200)
        resolve(response.data.data);
      else
        resolve([]);
    })
    .catch((err) => {
        console.log(err);
        reject(err);
    });
  });
}
function deleteOrder(idList) {
  return new Promise(async(resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
    .delete(`${API_URL}api/deleteOrder`, {
      headers: {
        Authorization: `bearer ${token}`
      },
      data: idList
    })
    .then(async (response) => {
      resolve(response.data.data);
    })
    .catch((err) => {
      reject(err);
    });
  });
}
function changeOrderStatus(formData) {
  return new Promise(async(resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
    .put(`${API_URL}api/changeOrderStatus`, formData,{
      headers: {
        Authorization: `bearer ${token}`
      }
    })
    .then(async (response) => {
      console.log(response.data);
      resolve(response.data.data);
    })
    .catch((err) => {
      console.log(err);
      reject(err);
    });
  });
}
function fetchCustomerOrders() {
  return new Promise(async(resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
    .get(API_URL + 'api/getMyOrders', {
      headers: {
        Authorization: `bearer ${token}`
      }
    })
    .then(async (response) => {
      if(response.data.status === 200)
        resolve(response.data.data);
      else
        resolve([]);
    })
    .catch((err) => {
        reject(err);
    });
  });
}
function placeOrder(formData) {
  return new Promise(async(resolve, reject) => {
    let token = await AsyncStorage.getItem('token');
    axios
    .post(`${API_URL}api/placeNewOrder`, formData,{
      headers: {
        Authorization: `bearer ${token}`
      }
    })
    .then(async (response) => {
      resolve(response.data);
    })
    .catch((err) => {
      reject(err);
    });
  });
}
export const orderService = {
  fetchVendorOrders,
  fetchOrderDetails,
  deleteOrder,
  changeOrderStatus,
  fetchCustomerOrders,
  placeOrder
};
