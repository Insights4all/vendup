import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {API_URL} from '../config';

function checkLogin(formData) {
  return new Promise((resolve, reject) => {
    axios
      .post(API_URL + 'api/login', formData)
      .then(async (response) => {
        await AsyncStorage.setItem('token', response.data.data.jwtToken);
        await AsyncStorage.setItem('role', response.data.data.role);
        resolve(response.data.data);
      })
      .catch((err) => {
        console.log(err);
        reject(err);
      });
  });
}
export const authService = {
  checkLogin,
};
